#!/bin/sh
# Linux / macOS:  sh run_engine.sh
cd "$(dirname "$0")/engine" && python3 server.py
