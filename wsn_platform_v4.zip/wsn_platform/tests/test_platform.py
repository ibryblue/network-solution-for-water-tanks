"""
test_platform.py -- automated checks for the whole platform.   Run:  python tests/test_platform.py
Covers: simulator regression, tank model, state snapshots, HTTP API (good and bad input),
dashboard JavaScript (with a fake DOM via Node.js, skipped if Node is not installed),
and the Node-RED flow file (structure + embedded JavaScript syntax).
"""
import io, json, os, shutil, socket, struct, subprocess, sys, tempfile, threading, time, unittest, urllib.request, urllib.error

os.environ["WSN_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")        # tests never touch your real database

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "engine"))

import numpy as np
import platform_core as core
import server
import store
import wsn_sim
import ablation
core.REAL_LAYOUT = os.path.join(ROOT, "__no_real_layout__")      # tests use the random layout


def get(port, path):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=30) as r:
            return r.status, r.read(), r.headers.get("Content-Type")
    except urllib.error.HTTPError as e:
        return e.code, e.read(), e.headers.get("Content-Type")


class CoreTests(unittest.TestCase):
    def test_regression_seed0(self):
        # numbers identical to the report's simulator (seed 0, 100 nodes)
        exp = {"PEGASIS": (107, 980, 1122), "LEACH": (152, 530, 878), "Direct": (20, 149, 1563)}
        for p, e in exp.items():
            s = core.summary(core.get_run(p, 0, 100))
            self.assertEqual((s["fnd"], s["hnd"], s["lnd"]), e, p)

    def test_tank_levels_bounds(self):
        run = core.get_run("PEGASIS", 3, 60)
        self.assertTrue(run.levels.min() >= 0 and run.levels.max() <= 100)
        self.assertEqual(run.levels.shape, (run.rounds + 1, 60))

    def test_state_invariants_all_protocols(self):
        for p in core.PROTOCOL_NAMES:
            run = core.get_run(p, 1, 80)
            for r in (0, 1, 7, run.rounds // 2, run.rounds, run.rounds + 50):
                st = core.state(run, r)
                self.assertEqual(st["alive"] + st["dead"], 80)
                self.assertEqual(st["alive"], sum(n["alive"] for n in st["nodes"]))
                rr = min(r, run.rounds)                                     # the engine clamps r to the last round
                prev = core.state(run, rr - 1) if rr > 0 else st
                for a, b in st["links"]:
                    self.assertTrue(-1 <= a < 80 and -1 <= b < 80)
                    # a node that dies DURING round r still transmits in round r,
                    # so the sender must have been alive at the START of the round
                    self.assertTrue(prev["nodes"][a]["alive"])
                for al in st["alerts"]:
                    self.assertTrue(st["nodes"][al["node"]]["alive"])    # dead nodes cannot alert
                self.assertTrue(all(0 <= n["energy"] <= 1.0001 for n in st["nodes"]))
            self.assertEqual(core.state(run, 0)["alive"], 80)
            self.assertEqual(core.state(run, run.rounds)["alive"], 0)
            self.assertEqual(core.state(run, 10**6)["round"], run.rounds)   # clamped

    def test_pegasis_link_count_and_leach_structure(self):
        run = core.get_run("PEGASIS", 2, 50)
        st = core.state(run, 5)
        self.assertEqual(len(st["links"]), st["alive"])                  # (alive-1) chain links + 1 to BS
        self.assertEqual(st["sink_packets"], 1)
        run = core.get_run("LEACH", 2, 50)
        st = core.state(run, 5)
        heads = [n for n in st["nodes"] if n["role"] == "head"]
        self.assertEqual(st["sink_packets"], len(heads))
        self.assertTrue(len(st["links"]) >= len(heads))

    def test_dead_node_keeps_last_known_level(self):
        run = core.get_run("Direct", 0, 100)
        st = core.state(run, run.rounds // 2)
        dead = [n for n in st["nodes"] if not n["alive"]]
        self.assertTrue(dead and all(n["age"] > 0 or True for n in dead))
        n0 = dead[0]
        d = int(run.death[n0["id"]])
        self.assertAlmostEqual(n0["level"], round(float(run.levels[d - 1, n0["id"]]), 1), places=1)

    def test_bad_arguments(self):
        for args in (("Nope", 0, 100), ("PEGASIS", -1, 100), ("PEGASIS", 0, 5), ("PEGASIS", 0, 1000)):
            with self.assertRaises(ValueError):
                core.check_args(*args)


class AlgorithmTests(unittest.TestCase):
    def test_simulator_selftests(self):
        self.assertTrue(wsn_sim.selftest(verbose=False))

    def test_multichain_partitions_alive_nodes(self):
        run = core.get_run("PEGASIS-MC", 4, 80)
        for r in (1, 50, run.rounds // 2):
            role = run.log[r - 1]["role"]
            allnodes = np.concatenate(role["chains"])
            self.assertEqual(len(allnodes), len(set(allnodes.tolist())))          # no node in two chains
            self.assertEqual(len(role["chains"]), len(role["leaders"]))
            for ch, ld in zip(role["chains"], role["leaders"]):
                self.assertIn(ld, ch.tolist())
                links = np.hypot(np.diff(run.pos[ch, 0]), np.diff(run.pos[ch, 1]))
                self.assertTrue((links < run.P.d0).all())                          # no long links inside a chain


class StoreAndParallelTests(unittest.TestCase):
    def test_store_roundtrip_and_replace(self):
        s = core.summary(core.get_run("LEACH", 7, 60))
        n0 = store.count()
        rid = store.save_run(s, "random")
        rid2 = store.save_run(s, "random")                                   # same key -> replaced, not duplicated
        self.assertEqual(store.count(), n0 + 1)
        c = store.curve(rid2)
        self.assertEqual(c["alive"], s["alive_curve"])
        self.assertIsNone(store.curve(rid))                                  # AUTOINCREMENT ids are never reused
        self.assertEqual(store.history(1)[0]["protocol"], "LEACH")
        self.assertEqual(store.history(5, "LEACH")[0]["seed"], 7)

    def test_sql_injection_is_harmless(self):
        n0 = store.count()
        self.assertEqual(store.history(5, "x'; DROP TABLE runs; --"), [])
        self.assertEqual(store.count(), n0)
        self.assertIsNone(store.curve(-5))

    def test_parallel_equals_sequential(self):
        jobs = [(v, "random", s) for v in ablation.VARIANTS[:3] for s in range(3)]
        self.assertEqual(sorted(ablation.run_jobs(jobs, 1), key=str), sorted(ablation.run_jobs(jobs, 2), key=str))


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = server.make_server("127.0.0.1", 0)
        cls.port = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def test_health_config_and_dashboard(self):
        s, b, ct = get(self.port, "/api/health"); self.assertEqual((s, json.loads(b)), (200, {"ok": True}))
        s, b, _ = get(self.port, "/api/config"); self.assertIn("PEGASIS", json.loads(b)["protocols"])
        s, b, ct = get(self.port, "/"); self.assertEqual(s, 200); self.assertIn(b"Water-Tank", b)
        self.assertIn("text/html", ct)

    def test_summary_state_compare(self):
        s, b, _ = get(self.port, "/api/summary?protocol=LEACH&seed=0&n=100")
        d = json.loads(b); self.assertEqual(s, 200); self.assertEqual(d["protocol"], "LEACH"); self.assertEqual(d["lnd"], d["rounds"])
        s, b, _ = get(self.port, "/api/state?protocol=PEGASIS&seed=0&n=100&round=300")
        d = json.loads(b); self.assertEqual((s, d["round"], len(d["nodes"])), (200, 300, 100))
        s, b, _ = get(self.port, "/api/compare?seed=0&n=100")
        d = json.loads(b)["results"]; self.assertEqual(set(d), set(core.PROTOCOL_NAMES))
        self.assertGreater(d["PEGASIS"]["hnd"], d["LEACH"]["hnd"])          # the report's main finding

    def test_history_endpoint_after_summary(self):
        get(self.port, "/api/summary?protocol=PEGASIS-E&seed=3&n=50")
        s, b, _ = get(self.port, "/api/history?limit=5&protocol=PEGASIS-E")
        d = json.loads(b); self.assertEqual(s, 200); self.assertEqual(d["runs"][0]["seed"], 3)
        s, b, _ = get(self.port, f"/api/curve?id={d['runs'][0]['id']}")
        self.assertEqual(s, 200); self.assertEqual(len(json.loads(b)["alive"]), d["runs"][0]["rounds"])
        for path in ("/api/history?limit=0", "/api/history?limit=999", "/api/history?protocol=x'--"):
            self.assertEqual(get(self.port, path)[0], 400, path)
        self.assertEqual(get(self.port, "/api/curve?id=99999")[0], 404)

    def test_compare_logs_every_protocol(self):
        get(self.port, "/api/compare?seed=11&n=40")
        s, b, _ = get(self.port, "/api/history?limit=50")
        got = {r["protocol"] for r in json.loads(b)["runs"] if r["seed"] == 11 and r["n"] == 40}
        self.assertEqual(got, set(core.PROTOCOL_NAMES))               # all six runs are in the database

    def test_summary_is_logged_with_layout(self):
        get(self.port, "/api/summary?protocol=LEACH&seed=12&n=40")
        row = [r for r in json.loads(get(self.port, "/api/history?limit=50&protocol=LEACH")[1])["runs"] if r["seed"] == 12][0]
        self.assertEqual(row["layout"], "random")
        self.assertIsNotNone(row["fnd"])

    def test_client_disconnect_is_silent(self):
        """A browser that refreshes mid-request (WinError 10053 / reset / broken pipe) must not print a traceback."""
        old, buf = sys.stderr, io.StringIO()
        sys.stderr = buf
        try:
            for _ in range(5):
                c = socket.create_connection(("127.0.0.1", self.port))
                c.sendall(b"GET /api/compare?seed=21&n=60 HTTP/1.1\r\nHost: x\r\n\r\n")
                c.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))   # close with RST
                c.close()
            time.sleep(1.5)
            for exc in (ConnectionAbortedError(10053, "aborted"), ConnectionResetError(), BrokenPipeError()):
                try:
                    raise exc
                except Exception:
                    self.srv.handle_error(None, ("127.0.0.1", 0))
        finally:
            sys.stderr = old
        self.assertNotIn("Traceback", buf.getvalue())
        self.assertEqual(get(self.port, "/api/health")[0], 200)          # still alive
        old, buf = sys.stderr, io.StringIO()
        sys.stderr = buf
        try:
            try:
                raise ValueError("a real bug")
            except ValueError:
                self.srv.handle_error(None, ("127.0.0.1", 0))
        finally:
            sys.stderr = old
        self.assertIn("a real bug", buf.getvalue())                      # real errors are NOT hidden

    def test_errors_do_not_crash_server(self):
        for path, code in (("/api/state?protocol=BAD", 400), ("/api/state?n=abc", 400), ("/api/state?seed=-5", 400),
                           ("/api/nope", 404), ("/not-a-page", 404), ("/../../etc/passwd", 404)):
            s, b, _ = get(self.port, path)
            self.assertEqual(s, code, path)
        s, _, _ = get(self.port, "/api/health"); self.assertEqual(s, 200)     # still alive

    @unittest.skipUnless(shutil.which("node"), "Node.js not installed")
    def test_dashboard_javascript_with_fake_dom(self):
        r = subprocess.run(["node", os.path.join(HERE, "js_smoke.js"), str(self.port)], capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("JS SMOKE OK", r.stdout)


class FlowTests(unittest.TestCase):
    @unittest.skipUnless(os.path.exists(os.path.join(ROOT, "node-red", "flow.json")), "flow not built yet")
    def test_flow_structure_and_function_nodes(self):
        r = subprocess.run([sys.executable, os.path.join(ROOT, "node-red", "check_flow.py")], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
