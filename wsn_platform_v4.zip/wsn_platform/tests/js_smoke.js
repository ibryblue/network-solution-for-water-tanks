// js_smoke.js -- runs the dashboard's JavaScript against the REAL engine with a fake DOM.
// It cannot check how things LOOK, but it proves the code runs without exceptions,
// fetches the right URLs, and draws every protocol at several rounds.
// usage: node js_smoke.js <port>
const fs = require("fs"), vm = require("vm"), path = require("path");
const port = process.argv[2];
const html = fs.readFileSync(path.join(__dirname, "..", "dashboard", "index.html"), "utf8");
const script = html.split("<script>")[1].split("</script>")[0];

const drawCalls = { n: 0 };
const ctx = new Proxy({}, { get: (t, k) => (k in t ? t[k] : (...a) => { drawCalls.n++; }), set: (t, k, v) => { t[k] = v; return true; } });
const values = { protocol: "PEGASIS", seed: "0", n: "100", speed: "5", slider: "0" };
function el(id) {
  const o = { style: {}, value: values[id] || "", textContent: "", innerHTML: "", width: 520, height: 640, max: 0,
    getContext: () => ctx, querySelector: () => el(id + "_q"), appendChild: () => {}, getBoundingClientRect: () => ({ left: 0, top: 0, width: 520 }) };
  return o;
}
const els = {};
const document = { getElementById: id => (els[id] = els[id] || el(id)), createElement: () => el("tmp") };
const sandbox = { window: { __NO_AUTOINIT__: true }, document, location: { pathname: "/" }, console,
  fetch: (u, o) => fetch("http://127.0.0.1:" + port + u, o), setInterval, clearInterval, Math, JSON, Promise };
vm.createContext(sandbox);
vm.runInContext(script, sandbox);

(async () => {
  let failures = 0;
  const check = (name, cond) => { if (!cond) failures++; console.log((cond ? "[PASS] " : "[FAIL] ") + name); };
  for (const proto of ["PEGASIS", "PEGASIS-2opt", "PEGASIS-E", "PEGASIS-MC", "LEACH", "Direct"]) {
    els["protocol"] = el("protocol"); els["protocol"].value = proto; values.protocol = proto;
    await vm.runInContext("load()", sandbox);
    const rounds = vm.runInContext("S.rounds", sandbox);
    check(proto + ": loaded run with rounds > 100 (" + rounds + ")", rounds > 100);
    for (const r of [0, 1, Math.floor(rounds / 2), rounds]) {
      await vm.runInContext("showRound(" + r + ")", sandbox);
      const got = vm.runInContext("S.state.round", sandbox);
      check(proto + ": showRound(" + r + ") -> state.round " + got, got === r);
    }
    check(proto + ": KPI text written", String(els["k_alive"].textContent).includes("/"));
    const body = String(els["cmpbody"].innerHTML);
    const selRows = body.match(/<tr class="sel">/g) || [];
    check(proto + ": comparison table has 6 rows and exactly the selected protocol highlighted",
          (body.match(/<tr /g) || []).length === 6 && selRows.length === 1 && new RegExp('<tr class="sel"><td[^>]*><b>' + proto + '</b>').test(body));
    check(proto + ": 'Selected:' note shows this protocol", String(els["cmpnote"].innerHTML).includes("<b>" + proto + "</b>"));
    check(proto + ": saved-runs card shows the database", String(els["hist"].innerHTML).includes("runs stored in engine/wsn.db"));
  }
  check("canvas drawing calls happened (" + drawCalls.n + ")", drawCalls.n > 1000);
  // the page must work under BOTH addresses: http://127.0.0.1:8000/  and  http://127.0.0.1:1880/wsn
  for (const [path, base] of [["/", "/"], ["/wsn", "/wsn/"], ["/wsn/", "/wsn/"]]) {
    const sb = { window: { __NO_AUTOINIT__: true }, document, location: { pathname: path }, console, fetch: sandbox.fetch, setInterval, clearInterval, Math, JSON, Promise };
    vm.createContext(sb); vm.runInContext(script, sb);
    check("BASE for page path '" + path + "' is '" + base + "'", vm.runInContext("BASE", sb) === base);
  }
  // every API name the dashboard calls must exist on the engine
  const used = [...new Set([...script.matchAll(/api\("(\w+)"/g)].map(m => m[1]))];
  for (const name of used) {
    const r = await fetch("http://127.0.0.1:" + port + "/api/" + name + "?protocol=PEGASIS&seed=0&n=100&round=1&limit=3");
    check("engine route /api/" + name + " exists (dashboard uses it) -> HTTP " + r.status, r.status === 200);
  }
  // banner shown when engine is unreachable
  sandbox.fetch = () => Promise.reject(new Error("offline"));
  await vm.runInContext("load()", sandbox);
  check("offline engine -> banner shows error", els["banner"].textContent.includes("Cannot reach"));
  console.log(failures ? "JS SMOKE FAILED" : "JS SMOKE OK");
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error("EXCEPTION", e); process.exit(1); });
