"""
check_flow.py -- validates node-red/flow.json without needing Node-RED installed.
Checks: JSON structure, unique ids, wires point to real nodes, only core node types,
embedded dashboard == dashboard/index.html, JavaScript of every function node
(syntax + behaviour with a mocked runtime and the REAL engine's output).
"""
import json, os, shutil, subprocess, sys, tempfile, threading
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "engine"))
import server

CORE_TYPES = {"tab", "comment", "http in", "http response", "http request", "template", "function",
              "inject", "catch", "debug"}
flow = json.load(open(os.path.join(HERE, "flow.json"), encoding="utf-8"))
ok = True
def check(name, cond):
    global ok
    ok &= bool(cond)
    print(("[PASS] " if cond else "[FAIL] ") + name)

ids = [n["id"] for n in flow]
check("node ids are unique", len(ids) == len(set(ids)))
tabs = [n for n in flow if n["type"] == "tab"]
check("exactly one tab", len(tabs) == 1)
check("only core Node-RED node types (nothing to install)", {n["type"] for n in flow} <= CORE_TYPES)
check("every node belongs to the tab", all(n.get("z") == tabs[0]["id"] for n in flow if n["type"] != "tab"))
bad = [(n["id"], t) for n in flow for out in n.get("wires", []) for t in out if t not in ids]
check("all wires point to existing nodes", not bad)
check("http-in routes are unique", len([n["url"] for n in flow if n["type"] == "http in"]) == len({n["url"] for n in flow if n["type"] == "http in"}))
tpl = [n for n in flow if n["type"] == "template"][0]
check("template uses 'plain' syntax (no mustache clash with JS)", tpl["syntax"] == "plain")
html = open(os.path.join(HERE, "..", "dashboard", "index.html"), encoding="utf-8").read()
check("embedded dashboard is identical to dashboard/index.html (re-run make_flow.py if not)", tpl["template"] == html)
resp = [n for n in flow if n["type"] == "http response" and n["id"] == "n0000007"][0]
senders = [n["name"] for n in flow for out in n.get("wires", []) for t in out if t == resp["id"]]
check("API http-response node is fed ONLY by the 'answer only once' guard", senders == ["answer only once"])
check("catch nodes scope existing http request nodes",
      all(s in ids for n in flow if n["type"] == "catch" for s in n["scope"]))

if shutil.which("node"):
    with tempfile.TemporaryDirectory() as d:                      # syntax-check each function body
        for n in [x for x in flow if x["type"] == "function"]:
            p = os.path.join(d, n["id"] + ".js")
            open(p, "w").write("(function(msg,node,flow,context,env,global){\n" + n["func"] + "\n})")
            r = subprocess.run(["node", "--check", p], capture_output=True, text=True)
            check(f"function '{n['name']}' has valid JavaScript syntax", r.returncode == 0)
    srv = server.make_server("127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    r = subprocess.run(["node", os.path.join(HERE, "run_functions.js"), os.path.join(HERE, "flow.json"),
                        str(srv.server_address[1])], capture_output=True, text=True, timeout=120)
    print(r.stdout.strip()); print(r.stderr.strip())
    check("function nodes behave correctly against the real engine", r.returncode == 0)
    srv.shutdown()
else:
    print("(Node.js not installed: function-node behaviour not tested)")
print("FLOW CHECK OK" if ok else "FLOW CHECK FAILED")
sys.exit(0 if ok else 1)
