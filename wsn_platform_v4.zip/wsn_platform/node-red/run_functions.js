// run_functions.js -- executes the flow's function nodes with a mocked Node-RED runtime.
// usage: node run_functions.js <path/to/flow.json> <engine_port>
const fs = require("fs");
const flow = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const port = process.argv[3];
const byName = n => flow.find(x => x.type === "function" && x.name === n);

function run(name, msg, env = {}, ctx = {}) {
  const store = ctx;
  const statusLog = [];
  const flowCtx = { get: k => store[k], set: (k, v) => { store[k] = v; } };
  const envObj = { get: k => env[k] };
  const nodeObj = { status: s => statusLog.push(s), warn() {}, error() {} };
  const fn = new Function("msg", "node", "flow", "context", "env", "global", byName(name).func);
  return { out: fn(msg, nodeObj, flowCtx, flowCtx, envObj, flowCtx), store, statusLog };
}
let failures = 0;
const check = (n, c) => { if (!c) failures++; console.log((c ? "[PASS] " : "[FAIL] ") + n); };

(async () => {
  // 1. URL builder
  let r = run("build engine URL", { req: { params: { endpoint: "state" }, query: { protocol: "LEACH", seed: "0", n: "100", round: "10" } } });
  check("URL builder forwards query string to the engine",
        r.out[0] && r.out[0].url === "http://127.0.0.1:8000/api/state?protocol=LEACH&seed=0&n=100&round=10" && r.out[1] === null);
  r = run("build engine URL", { req: { params: { endpoint: "state" }, query: {} } }, { ENGINE_URL: "http://10.0.0.5:9000" });
  check("ENGINE_URL environment variable is respected", r.out[0].url === "http://10.0.0.5:9000/api/state");
  for (const bad of ["../etc/passwd", "admin", ""]) {
    r = run("build engine URL", { req: { params: { endpoint: bad }, query: {} } });
    check("endpoint '" + bad + "' is rejected with 404", r.out[0] === null && r.out[1].statusCode === 404);
  }
  // 1b. gateway emulation: every endpoint the dashboard uses, through the URL builder, must return the engine's data
  const html = fs.readFileSync(require("path").join(__dirname, "..", "dashboard", "index.html"), "utf8");
  const used = [...new Set([...html.matchAll(/api\("(\w+)"/g)].map(m => m[1]))];
  const allowed = [...byName("build engine URL").func.match(/const allowed = \[(.*?)\]/)[1].matchAll(/"(\w+)"/g)].map(m => m[1]);
  for (const name of used) {
    check("dashboard endpoint '" + name + "' is whitelisted in the Node-RED gateway", allowed.includes(name));
    const q = { protocol: "LEACH", seed: "0", n: "100", round: "3", limit: "3" };
    const built = run("build engine URL", { req: { params: { endpoint: name }, query: q } }).out[0];
    const viaGateway = await (await fetch(built.url.replace("http://127.0.0.1:8000", "http://127.0.0.1:" + port))).json();
    const direct = await (await fetch("http://127.0.0.1:" + port + "/api/" + name + "?" + new URLSearchParams(q))).json();
    check("gateway URL for '" + name + "' returns the same JSON as the engine", JSON.stringify(viaGateway) === JSON.stringify(direct));
  }
  // 2. engine-down message
  r = run("502 message", {});
  check("engine-down function returns HTTP 502 with a help text", r.out.statusCode === 502 && /server\.py/.test(r.out.payload.error));
  r = run("drop engine headers", { statusCode: "ECONNREFUSED", payload: "Error: connect ECONNREFUSED : http://x" });
  check("failed request (string statusCode) becomes a clean 502 JSON message", r.out.statusCode === 502 && /server\.py/.test(r.out.payload.error));
  r = run("answer only once", { res: { _res: { headersSent: true } }, payload: 1 });
  check("guard drops a second answer when headers were already sent", r.out === null);
  r = run("answer only once", { res: { _res: { headersSent: false, writableEnded: false } }, payload: 1 });
  check("guard lets the first answer through", r.out && r.out.payload === 1);
  r = run("answer only once", { payload: 1 });
  check("guard tolerates messages without res", r.out && r.out.payload === 1);
  r = run("build engine URL", { req: { params: { endpoint: "state" }, query: {} } });
  check("URL builder no longer sets msg.method (removes the Node-RED warning)", r.out[0].method === undefined);
  r = run("advance clock", {}, {}, {});
  check("clock function no longer sets msg.method", r.out.method === undefined);
  r = run("drop engine headers", { headers: { "content-length": "999" }, payload: { a: 1 }, statusCode: 400 });
  check("engine headers are removed but status code and payload are kept",
        r.out.headers === undefined && r.out.statusCode === 400 && r.out.payload.a === 1);
  // 3. clock
  const ctx = {};
  r = run("advance clock", {}, {}, ctx);
  check("clock advances by 5 h by default and builds the state URL", /round=5$/.test(r.out.url) && /protocol=PEGASIS&seed=0&n=100/.test(r.out.url));
  r = run("advance clock", {}, { STEP: "24", PROTOCOL: "LEACH" }, ctx);
  check("clock keeps its value in flow context and honours STEP/PROTOCOL", /round=29$/.test(r.out.url) && /protocol=LEACH/.test(r.out.url));
  // 4. alert detection against REAL engine output
  const get = async q => (await fetch("http://127.0.0.1:" + port + "/api/state?" + q)).json();
  const s1 = await get("protocol=PEGASIS&seed=0&n=100&round=100");
  const c2 = {};
  r = run("detect NEW alerts", { payload: s1 }, {}, c2);
  check("first tick reports every current alert (" + s1.alerts.length + ")", r.out && r.out.payload.new_alerts.length === s1.alerts.length);
  r = run("detect NEW alerts", { payload: s1 }, {}, c2);
  check("identical second tick reports nothing (no duplicates)", r.out === null);
  const s2 = await get("protocol=PEGASIS&seed=0&n=100&round=105");
  const known = new Set(s1.alerts.map(a => a.node + ":" + a.type));
  const expectNew = s2.alerts.filter(a => !known.has(a.node + ":" + a.type)).length;
  r = run("detect NEW alerts", { payload: s2 }, {}, c2);
  check("later tick reports only the " + expectNew + " new alerts", expectNew === 0 ? r.out === null : r.out.payload.new_alerts.length === expectNew);
  const last = await get("protocol=PEGASIS&seed=0&n=100&round=100000");
  const c3 = { round: 77 };
  run("detect NEW alerts", { payload: last }, {}, c3);
  check("when the network is dead the demo clock restarts", c3.round === 0);
  r = run("detect NEW alerts", { payload: { error: "x" } }, {}, {});
  check("error payload from engine is ignored safely", r.out === null);
  r = run("reset", {}, {}, { round: 9, alerted: { a: 1 } });
  check("reset function clears clock", r.store.round === 0);
  console.log(failures ? "FUNCTION NODES FAILED" : "FUNCTION NODES OK");
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error("EXCEPTION", e); process.exit(1); });
