"""
make_flow.py -- generates node-red/flow.json  (run:  python node-red/make_flow.py)

The flow uses ONLY core Node-RED nodes (http in, http request, http response, template,
function, inject, catch, debug, comment) so nothing extra has to be installed.

  Flow 1  "Dashboard + API gateway":  Node-RED serves the dashboard at  /wsn  and forwards
          /wsn/api/<endpoint> to the Python engine (default http://127.0.0.1:8000).
  Flow 2  "Tank alert monitor":       every 2 s it advances the simulated clock, asks the engine for the
          network state, and emits a message ONLY for tank alerts that are new.
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
html = open(os.path.join(HERE, "..", "dashboard", "index.html"), encoding="utf-8").read()
TAB = "a1b2c3d4e5f60001"

URL_BUILDER = r'''// Forward /wsn/api/<endpoint>?<query> to the Python engine
const allowed = ["health", "config", "summary", "state", "compare", "history", "curve"];
const ep = msg.req.params.endpoint;
if (!allowed.includes(ep)) {
    msg.statusCode = 404;
    msg.payload = { error: "unknown endpoint" };
    return [null, msg];
}
const qs = new URLSearchParams(msg.req.query).toString();
const base = env.get("ENGINE_URL") || "http://127.0.0.1:8000";
msg.url = base + "/api/" + ep + (qs ? "?" + qs : "");
return [msg, null];'''

ENGINE_DOWN = r'''// The http request node failed -> the Python engine is not running
msg.statusCode = 502;
msg.payload = { error: "The Python engine is not running. Start it with:  python engine/server.py" };
return msg;'''

ADVANCE = r'''// Advance the simulated clock and ask the engine for the network state
const protocol = env.get("PROTOCOL") || "PEGASIS";
const seed = env.get("SEED") || "0";
const n = env.get("N") || "100";
const step = parseInt(env.get("STEP") || "5", 10);
const base = env.get("ENGINE_URL") || "http://127.0.0.1:8000";
let r = (flow.get("round") || 0) + step;
flow.set("round", r);
msg.url = base + "/api/state?protocol=" + protocol + "&seed=" + seed + "&n=" + n + "&round=" + r;
return msg;'''

DETECT = r'''// Emit a message only for tank alerts that were NOT present in the previous tick
const st = msg.payload;
if (!st || st.error || !Array.isArray(st.alerts)) { return null; }
const before = flow.get("alerted") || {};
const now = {};
const fresh = [];
for (const a of st.alerts) {
    const key = a.node + ":" + a.type;
    now[key] = true;
    if (!before[key]) {
        fresh.push("Tank #" + a.node + ": " + a.type.toUpperCase() + " (" + a.level + " %) at hour " + st.round);
    }
}
flow.set("alerted", now);
if (st.round >= st.rounds) { flow.set("round", 0); flow.set("alerted", {}); }   // network is dead: restart the demo
node.status({ fill: fresh.length ? "red" : "green", shape: "dot",
              text: "h" + st.round + ": " + st.alive + " alive, " + fresh.length + " new alerts" });
if (fresh.length === 0) { return null; }
msg.payload = { hour: st.round, nodes_alive: st.alive, coverage_pct: st.coverage, new_alerts: fresh };
return msg;'''

DROP_HEADERS = r'''// 1) a failed request arrives here with a non-numeric statusCode (e.g. "ECONNREFUSED") -> make it a clean 502
if (typeof msg.statusCode !== "number") {
    msg.statusCode = 502;
    msg.payload = { error: "The Python engine is not reachable. Start it with:  python engine/server.py" };
}
// 2) the engine's Content-Length would be wrong after Node-RED re-serialises the JSON -> drop its headers
delete msg.headers;
return msg;'''

GUARD = r'''// Answer each browser request ONLY ONCE. A failed http request can reach this point twice
// (once via the catch node, once via the normal output); the second answer would raise ERR_HTTP_HEADERS_SENT.
const res = msg.res && msg.res._res;
if (res && (res.headersSent || res.writableEnded)) { return null; }
return msg;'''

RESET = r'''flow.set("round", 0);
flow.set("alerted", {});
node.status({ fill: "blue", shape: "ring", text: "clock reset to hour 0" });
return null;'''

def node(id, type, x, y, **kw):
    d = dict(id=id, type=type, z=TAB, x=x, y=y)
    d.update(kw)
    return d

nodes = [
    dict(id=TAB, type="tab", label="WSN Water-Tank Platform", disabled=False,
         info="Dashboard + API gateway for the Python engine, and a tank-alert monitor.",
         env=[dict(name="ENGINE_URL", value="http://127.0.0.1:8000", type="str"),
              dict(name="PROTOCOL", value="PEGASIS", type="str"),
              dict(name="SEED", value="0", type="str"),
              dict(name="N", value="100", type="str"),
              dict(name="STEP", value="5", type="str")]),

    node("c0000001", "comment", 200, 40, name="FLOW 1 - dashboard and API gateway (open http://localhost:1880/wsn)",
         info="Start the Python engine first:  python engine/server.py", wires=[]),
    node("n0000001", "http in", 130, 100, name="GET /wsn", url="/wsn", method="get", upload=False, swaggerDoc="", wires=[["n0000002"]]),
    node("n0000002", "template", 340, 100, name="Dashboard HTML", field="payload", fieldType="msg", format="html",
         syntax="plain", template=html, output="str", wires=[["n0000003"]]),
    node("n0000003", "http response", 560, 100, name="", statusCode="", headers={"Content-Type": "text/html; charset=utf-8"}, wires=[]),

    node("n0000004", "http in", 160, 180, name="GET /wsn/api/:endpoint", url="/wsn/api/:endpoint", method="get", upload=False, swaggerDoc="", wires=[["n0000005"]]),
    node("n0000005", "function", 400, 180, name="build engine URL", func=URL_BUILDER, outputs=2, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000006"], ["n0000020"]]),
    node("n0000006", "http request", 630, 160, name="Python engine", method="GET", ret="obj", paytoqs="ignore", url="",
         tls="", persist=False, proxy="", insecureHTTPParser=False, authType="", senderr=False, headers=[], wires=[["n0000019"]]),
    node("n0000007", "http response", 830, 180, name="", statusCode="", headers={}, wires=[]),
    node("n0000019", "function", 740, 160, name="drop engine headers", func=DROP_HEADERS, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000020"]]),
    node("n0000020", "function", 860, 130, name="answer only once", func=GUARD, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000007"]]),
    node("n0000008", "catch", 630, 240, name="engine down?", scope=["n0000006"], uncaught=False, wires=[["n0000009"]]),
    node("n0000009", "function", 810, 240, name="502 message", func=ENGINE_DOWN, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000020"]]),

    node("c0000002", "comment", 200, 320, name="FLOW 2 - tank alert monitor (the 'automation' part)",
         info="Replace the debug node by a Telegram / e-mail node to get real notifications.", wires=[]),
    node("n0000010", "inject", 140, 380, name="tick every 2 s", props=[dict(p="payload"), dict(p="topic", vt="str")],
         repeat="2", crontab="", once=False, onceDelay=0.1, topic="", payload="", payloadType="date", wires=[["n0000011"]]),
    node("n0000011", "function", 360, 380, name="advance clock", func=ADVANCE, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000012"]]),
    node("n0000012", "http request", 560, 380, name="Python engine", method="GET", ret="obj", paytoqs="ignore", url="",
         tls="", persist=False, proxy="", insecureHTTPParser=False, authType="", senderr=False, headers=[], wires=[["n0000013"]]),
    node("n0000013", "function", 760, 380, name="detect NEW alerts", func=DETECT, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000014"]]),
    node("n0000014", "debug", 960, 380, name="tank alerts", active=True, tosidebar=True, console=False, tostatus=False,
         complete="payload", targetType="msg", statusVal="", statusType="auto", wires=[]),
    node("n0000015", "catch", 560, 440, name="engine down?", scope=["n0000012"], uncaught=False, wires=[["n0000016"]]),
    node("n0000016", "debug", 760, 440, name="engine unreachable", active=True, tosidebar=True, console=False, tostatus=False,
         complete="error.message", targetType="msg", statusVal="", statusType="auto", wires=[]),
    node("n0000017", "inject", 140, 460, name="reset clock", props=[dict(p="payload")], repeat="", crontab="", once=False,
         onceDelay=0.1, topic="", payload="", payloadType="date", wires=[["n0000018"]]),
    node("n0000018", "function", 360, 460, name="reset", func=RESET, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[[]]),
]

out = os.path.join(HERE, "flow.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump(nodes, f, indent=2, ensure_ascii=False)
print("wrote", out, "-", len(nodes), "nodes")
