@echo off
REM Windows: double-click this file (needs Python 3 and: pip install numpy)
cd /d "%~dp0engine"
python server.py
pause
