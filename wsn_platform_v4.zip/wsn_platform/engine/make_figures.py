"""make_figures.py -- figures for the report (real map + ablation).  Run: python make_figures.py   (needs matplotlib, scipy)"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import ablation as ab
from wsn_sim import PROTOCOLS, build_chain, build_chain_2opt, e_tx, _dist_to_sink

OUT = os.path.join(ab.HERE, "..", "report_figures")
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.size": 9, "axes.grid": True, "grid.alpha": 0.3, "savefig.bbox": "tight"})
COL = {"Direct": "#7f7f7f", "LEACH": "#d95f02", "PEGASIS": "#1b6ca8", "PEGASIS-2opt": "#2e9d5b", "PEGASIS-E": "#00897b", "PEGASIS-MC": "#8e44ad"}

P, pos = ab.setup("real", 0)
idx, ds = np.arange(len(pos)), _dist_to_sink(P, pos)

# ---- Fig 1: greedy chain vs 2-opt chain on the real map
fig, axs = plt.subplots(1, 2, figsize=(6.9, 3.6), sharey=True)
for ax, (name, fn) in zip(axs, (("(a) greedy chain (original PEGASIS)", lambda: build_chain(pos, idx, ds)),
                                ("(b) after 2-opt local search", lambda: build_chain_2opt(P, pos, idx, ds)))):
    ch = fn()
    seg = np.hypot(np.diff(pos[ch, 0]), np.diff(pos[ch, 1]))
    energy = float(e_tx(P, P.k_data, seg).sum())
    for i, d in enumerate(seg):
        long_ = d >= P.d0
        ax.plot(pos[ch[i:i + 2], 0], pos[ch[i:i + 2], 1], color="crimson" if long_ else "#1b6ca8", lw=1.8 if long_ else 0.8)
    ax.scatter(pos[:, 0], pos[:, 1], s=9, color="k", zorder=3)
    ax.plot(*P.sink, marker="*", ms=14, color="gold", mec="k", ls="none", zorder=5)
    ax.set_title(f"{name}\nlinks >= d0: {int((seg >= P.d0).sum())}, link energy {energy * 1e3:.1f} mJ", fontsize=8)
    ax.set_xlabel("x (m)"); ax.set_aspect("equal")
axs[0].set_ylabel("y (m)")
fig.savefig(os.path.join(OUT, "fig_real_chains.pdf")); fig.savefig(os.path.join(OUT, "fig_real_chains.png"), dpi=200); plt.close(fig)

# ---- Fig 2: alive nodes vs round on the real map
fig, ax = plt.subplots(figsize=(3.4, 2.6))
for name in ("Direct", "LEACH", "PEGASIS", "PEGASIS-2opt", "PEGASIS-E", "PEGASIS-MC"):
    r = PROTOCOLS[name](P, pos, np.random.default_rng(10_000))
    a = np.concatenate([[len(pos)], r["alive"]])
    ax.plot(np.arange(len(a)), a, color=COL[name], label=name, lw=1.3)
ax.set_xlabel("Round (hours)"); ax.set_ylabel("Alive nodes"); ax.legend(frameon=False, fontsize=7)
fig.savefig(os.path.join(OUT, "fig_real_alive.pdf")); fig.savefig(os.path.join(OUT, "fig_real_alive.png"), dpi=200); plt.close(fig)

# ---- Fig 3: ablation (30 random layouts)
seeds = list(range(30))
res = ab.collect(ab.run_jobs([(v, "random", s) for v in ab.VARIANTS for s in seeds], 1), seeds)
fig, axs = plt.subplots(1, 3, figsize=(6.9, 2.8), sharey=True)
names = [ab.vname(v) for v in ab.VARIANTS]
for c, (ax, m) in enumerate(zip(axs, ("FND", "HND", "LND"))):
    vals = [res[v][:, c].mean() for v in ab.VARIANTS]
    errs = [ab.ci95(res[v][:, c]) for v in ab.VARIANTS]
    cols = ["#c0392b" if v == ("greedy", False, "rotate") else "#00897b" if v == ("2opt", False, "energy") else "#9aa3ab" for v in ab.VARIANTS]
    ax.barh(range(8), vals, xerr=errs, color=cols, capsize=2)
    ax.set_yticks(range(8)); ax.set_yticklabels(names, fontsize=7); ax.set_title(m); ax.invert_yaxis(); ax.set_xlabel("rounds")
fig.savefig(os.path.join(OUT, "fig_ablation.pdf")); fig.savefig(os.path.join(OUT, "fig_ablation.png"), dpi=200); plt.close(fig)
print("figures written to", os.path.abspath(OUT))
