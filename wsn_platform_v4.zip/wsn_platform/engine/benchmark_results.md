# Benchmark results

## A. REAL layout: 80 buildings from OpenStreetMap, block 400 m, base station [200.0, 450.0]
(LEACH is random: mean ± 95% CI over 30 runs. The other protocols are deterministic: one run.)

| Protocol | FND | HND | LND | hops/round |
|---|---|---|---|---|
| Direct | 2 | 16 | 1097 | 1.0 |
| LEACH | 16 ± 2 | 66 ± 2 | 380 ± 35 | 1.4 |
| PEGASIS | 4 | 339 | 799 | 27.6 |
| PEGASIS-2opt | 160 | 493 | 975 | 32.8 |
| PEGASIS-E | 677 | 925 | 945 | 57.0 |
| PEGASIS-MC | 677 | 839 | 886 | 53.2 |

## B. 30 random layouts (80 nodes, 400 m block, base station 50 m north)
(mean ± 95% CI)

| Protocol | FND | HND | LND | hops/round |
|---|---|---|---|---|
| Direct | 3 ± 0 | 17 ± 2 | 1241 ± 96 | 1.0 |
| LEACH | 14 ± 2 | 57 ± 3 | 403 ± 57 | 1.4 |
| PEGASIS | 38 ± 13 | 351 ± 27 | 936 ± 46 | 26.5 |
| PEGASIS-2opt | 112 ± 9 | 505 ± 22 | 1027 ± 37 | 31.3 |
| PEGASIS-E | 569 ± 43 | 959 ± 15 | 985 ± 16 | 58.9 |
| PEGASIS-MC | 278 ± 107 | 791 ± 60 | 953 ± 26 | 42.2 |

### Paired Wilcoxon test against plain PEGASIS (same 30 layouts)

| Protocol | metric | mean change | p-value |
|---|---|---|---|
| PEGASIS-2opt | FND | +199.5% | <0.001 |
| PEGASIS-2opt | HND | +43.9% | <0.001 |
| PEGASIS-2opt | LND | +9.7% | <0.001 |
| PEGASIS-E | FND | +1414.5% | <0.001 |
| PEGASIS-E | HND | +173.6% | <0.001 |
| PEGASIS-E | LND | +5.2% | 0.036 |
| PEGASIS-MC | FND | +639.1% | <0.001 |
| PEGASIS-MC | HND | +125.6% | <0.001 |
| PEGASIS-MC | LND | +1.8% | 0.797 |
| LEACH | FND | -63.0% | <0.001 |
| LEACH | HND | -83.7% | <0.001 |
| LEACH | LND | -56.9% | <0.001 |