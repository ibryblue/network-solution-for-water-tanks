"""
prepare_layout.py -- turn REAL building footprints (OpenStreetMap GeoJSON) into the platform's layout.

Usage (from the engine folder):
    python prepare_layout.py export.geojson
    python prepare_layout.py export.geojson --max-nodes 100 --block 250 --min-area 40

It writes real_layout.json next to this file. When that file exists, the platform automatically
uses the REAL building positions (one node = one building = one rooftop tank) instead of random ones.
Delete real_layout.json to go back to the random layout.
"""
import argparse, json, math, os, sys
import numpy as np

SKIP = {"garage", "garages", "shed", "roof", "carport", "hut", "cabin", "kiosk", "service", "container", "greenhouse"}

def rings(geom):
    t, c = geom["type"], geom["coordinates"]
    if t == "Polygon": return [c[0]]
    if t == "MultiPolygon": return [p[0] for p in c]
    return []

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("geojson"); ap.add_argument("--max-nodes", type=int, default=100)
    ap.add_argument("--block", type=float, default=250.0, help="side of the square window to search (m)")
    ap.add_argument("--min-area", type=float, default=40.0, help="ignore footprints smaller than this (m2)")
    ap.add_argument("--sink-offset", type=float, default=50.0, help="base station distance north of the block (m)")
    a = ap.parse_args()
    d = json.load(open(a.geojson, encoding="utf-8"))
    feats = d.get("features", [])
    if not feats:
        sys.exit("The file has 0 features: the Overpass query returned nothing. See the instructions you were given.")
    pts = []                                    # (lon, lat, area_m2 or None)
    for f in feats:
        g, p = f.get("geometry") or {}, f.get("properties") or {}
        if str(p.get("building", "yes")).lower() in SKIP: continue
        rs = rings(g) if g else []
        if rs:
            for r in rs:
                ar = np.array([c[:2] for c in r], float)
                lon0, lat0 = ar[:, 0].mean(), ar[:, 1].mean()
                x = (ar[:, 0] - lon0) * math.cos(math.radians(lat0)) * 111320; y = (ar[:, 1] - lat0) * 110574
                area = 0.5 * abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
                if area >= a.min_area: pts.append((lon0, lat0, area))
        elif g.get("type") == "Point":
            pts.append((g["coordinates"][0], g["coordinates"][1], None))
    if len(pts) < 10: sys.exit(f"Only {len(pts)} usable buildings found (need at least 10).")
    lon, lat = np.array([p[0] for p in pts]), np.array([p[1] for p in pts])
    lat0, lon0 = lat.mean(), lon.mean()
    X = (lon - lon0) * math.cos(math.radians(lat0)) * 111320; Y = (lat - lat0) * 110574
    # densest square window
    best, bx, by = -1, 0, 0
    for wx in np.arange(X.min(), X.max() + 1, 25.0):
        for wy in np.arange(Y.min(), Y.max() + 1, 25.0):
            c = int(((X >= wx) & (X < wx + a.block) & (Y >= wy) & (Y < wy + a.block)).sum())
            if c > best: best, bx, by = c, wx, wy
    sel = np.flatnonzero((X >= bx) & (X < bx + a.block) & (Y >= by) & (Y < by + a.block))
    if len(sel) > a.max_nodes:                  # keep the buildings closest to the window centre
        cx, cy = bx + a.block / 2, by + a.block / 2
        sel = sel[np.argsort(np.hypot(X[sel] - cx, Y[sel] - cy))[:a.max_nodes]]
    if len(sel) < 10: sys.exit(f"The densest {a.block:.0f} m window has only {len(sel)} buildings. Try --block 400.")
    px, py = X[sel] - X[sel].min(), Y[sel] - Y[sel].min()
    field = float(math.ceil(max(px.max(), py.max()) / 10.0) * 10.0)
    out = dict(positions=[[round(float(u), 1), round(float(v), 1)] for u, v in zip(px, py)], field=field,
               sink=[round(field / 2, 1), field + a.sink_offset], source=os.path.basename(a.geojson),
               origin_lat_lon=[round(float(lat0), 6), round(float(lon0), 6)], n_features=len(feats), n_usable=len(pts),
               note="1 building = 1 rooftop tank (assumption). Base station placed north of the block (assumption).")
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "real_layout.json")
    json.dump(out, open(path, "w"))
    print(f"features in file: {len(feats)} | usable buildings: {len(pts)} | densest window: {len(sel)} buildings kept")
    print(f"block size: {px.max():.0f} x {py.max():.0f} m | base station at {out['sink']} | wrote {path}")

if __name__ == "__main__":
    main()
