"""
server.py -- HTTP front door of the water-tank monitoring platform (standard library only).

Start:   python server.py              -> http://127.0.0.1:8000
         python server.py --port 9000

Endpoints (all GET, all stateless, all JSON):
  /api/health                                   -> {"ok": true}
  /api/config                                   -> protocols and defaults
  /api/summary?protocol=PEGASIS&seed=0&n=100    -> FND/HND/LND and the alive-nodes curve
  /api/state?protocol=PEGASIS&seed=0&n=100&round=300
                                                -> full snapshot of the network at that round
  /api/compare?seed=0&n=100                     -> all protocols side by side
  /api/history?limit=20&protocol=LEACH          -> runs saved in the SQLite database (engine/wsn.db)
  /api/curve?id=3                               -> alive/energy curve of one saved run
  /                                             -> the dashboard (dashboard/index.html)
"""
from __future__ import annotations
import argparse, json, os, sys, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import platform_core as core
import store

HERE = os.path.dirname(os.path.abspath(__file__))
# ConnectionAbortedError (WinError 10053), ConnectionResetError (10054) and BrokenPipeError are all ConnectionError subclasses
CONN_ERRORS = (ConnectionError, BrokenPipeError, TimeoutError)
DASHBOARD = os.path.join(HERE, "..", "dashboard", "index.html")
LOCK = threading.Lock()          # simulations are cached; one at a time keeps it simple and safe


def _int(q, key, default):
    try:
        return int(q.get(key, [default])[0])
    except ValueError:
        raise ValueError(f"'{key}' must be an integer")


def route(path: str, q: dict):
    """Return (status, python-object) for an API path."""
    if path == "/api/health":
        return 200, {"ok": True}
    if path == "/api/config":
        return 200, dict(protocols=core.PROTOCOL_NAMES,
                         defaults=dict(protocol="PEGASIS", seed=0, n=100),
                         low_level=core.LOW_LEVEL, high_level=core.HIGH_LEVEL)
    if path == "/api/history":
        limit = _int(q, "limit", 20)
        proto = q.get("protocol", [None])[0]
        if not 1 <= limit <= 200:
            raise ValueError("limit must be 1..200")
        if proto is not None and proto not in core.PROTOCOL_NAMES:
            raise ValueError(f"protocol must be one of {core.PROTOCOL_NAMES}")
        with LOCK:
            return 200, dict(runs=store.history(limit, proto), total=store.count())
    if path == "/api/curve":
        with LOCK:
            c = store.curve(_int(q, "id", 0))
        return (200, c) if c else (404, {"error": "no such saved run"})
    protocol = q.get("protocol", ["PEGASIS"])[0]
    seed, n = _int(q, "seed", 0), _int(q, "n", 100)
    core.check_args(protocol, seed, n)
    with LOCK:
        if path == "/api/summary":
            s = core.summary(core.get_run(protocol, seed, n))
            store.save_run(s, core.layout_label())
            return 200, s
        if path == "/api/state":
            return 200, core.state(core.get_run(protocol, seed, n), _int(q, "round", 0))
        if path == "/api/compare":
            result = core.compare(seed, n)
            for p in core.PROTOCOL_NAMES:                      # every simulated run is logged, not only the selected one
                store.save_run(core.summary(core.get_run(p, seed, n)), core.layout_label())
            return 200, result
    return 404, {"error": "unknown endpoint"}


class Handler(BaseHTTPRequestHandler):
    server_version = "WSNPlatform/1.0"

    def _send(self, status, body: bytes, ctype: str):
        try:
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")   # not needed for same-origin pages; harmless
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except CONN_ERRORS:                 # the browser refreshed / closed the tab before we finished: nothing to do
            self.close_connection = True

    def do_GET(self):
        u = urlparse(self.path)
        try:
            if u.path in ("/", "/index.html"):
                with open(DASHBOARD, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            if u.path.startswith("/api/"):
                status, obj = route(u.path, parse_qs(u.query))
                return self._send(status, json.dumps(obj).encode(), "application/json")
            return self._send(404, b'{"error": "not found"}', "application/json")
        except ValueError as e:
            return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")
        except Exception as e:                              # never crash the server
            return self._send(500, json.dumps({"error": f"internal error: {e}"}).encode(), "application/json")

    def log_message(self, fmt, *args):                      # quiet console
        pass


class QuietServer(ThreadingHTTPServer):
    """Browsers that refresh or close a tab mid-request make the handler thread fail with ConnectionAbortedError /
    ConnectionResetError / BrokenPipeError. That is normal, so it is ignored instead of printing a long traceback;
    every OTHER exception is still reported by the standard handler."""

    def handle_error(self, request, client_address):
        if isinstance(sys.exc_info()[1], CONN_ERRORS):
            return
        super().handle_error(request, client_address)


def make_server(host="127.0.0.1", port=8000):
    return QuietServer((host, port), Handler)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    a = ap.parse_args()
    srv = make_server(a.host, a.port)
    print(f"Water-tank WSN platform running:  http://{a.host}:{a.port}   (Ctrl+C to stop)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")
