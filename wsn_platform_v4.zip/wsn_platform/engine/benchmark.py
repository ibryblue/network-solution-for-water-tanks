"""
benchmark.py -- compares all routing protocols, on (A) your REAL building layout and (B) 30 random layouts
of the same size/density.   Run:  python benchmark.py        (needs numpy and scipy:  pip install scipy)
Writes benchmark_results.md next to this file.  FND/HND/LND = round when the first / half / last node dies.
"""
import json, os
from dataclasses import replace
import numpy as np
from scipy import stats
from wsn_sim import Params, PROTOCOLS, make_layout

HERE = os.path.dirname(os.path.abspath(__file__))
NAMES = list(PROTOCOLS)
SEEDS = 30

def ci95(x):
    x = np.asarray(x, float)
    return 0.0 if len(x) < 2 else float(stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x)))

def run(P, pos, name, seed):
    r = PROTOCOLS[name](P, pos, np.random.default_rng(10_000 + seed))
    return r["fnd"], r["hnd"], r["lnd"], r["hops"]

def table(rows):
    out = ["| Protocol | FND | HND | LND | hops/round |", "|---|---|---|---|---|"]
    for n in NAMES:
        a = np.array(rows[n], float)
        f = lambda c: f"{a[:, c].mean():.0f} \u00b1 {ci95(a[:, c]):.0f}" if len(a) > 1 and ci95(a[:, c]) > 0 else f"{a[:, c].mean():.0f}"
        out.append(f"| {n} | {f(0)} | {f(1)} | {f(2)} | {a[:, 3].mean():.1f} |")
    return "\n".join(out)

md = ["# Benchmark results", ""]
real = os.path.join(HERE, "real_layout.json")
if os.path.exists(real):
    L = json.load(open(real)); pos = np.array(L["positions"])
    P = replace(Params(), n_nodes=len(pos), field=float(L["field"]), sink=tuple(L["sink"]))
    rows_real = {n: [run(P, pos, n, s) for s in (range(SEEDS) if n == "LEACH" else [0])] for n in NAMES}
    rows = rows_real
    md += [f"## A. REAL layout: {len(pos)} buildings from OpenStreetMap, block {L['field']:.0f} m, base station {L['sink']}",
           "(LEACH is random: mean \u00b1 95% CI over 30 runs. The other protocols are deterministic: one run.)", "", table(rows), ""]
Pr = replace(Params(), n_nodes=80, field=400.0, sink=(200.0, 450.0))
rows = {n: [] for n in NAMES}
for s in range(SEEDS):
    pos = make_layout(Pr, np.random.default_rng(s))
    for n in NAMES:
        rows[n].append(run(Pr, pos, n, s))
md += ["## B. 30 random layouts (80 nodes, 400 m block, base station 50 m north)", "(mean \u00b1 95% CI)", "", table(rows), "",
       "### Paired Wilcoxon test against plain PEGASIS (same 30 layouts)", "", "| Protocol | metric | mean change | p-value |", "|---|---|---|---|"]
base = np.array(rows["PEGASIS"], float)
for n in ("PEGASIS-2opt", "PEGASIS-E", "PEGASIS-MC", "LEACH"):
    a = np.array(rows[n], float)
    for c, m in enumerate(("FND", "HND", "LND")):
        p = stats.wilcoxon(a[:, c], base[:, c]).pvalue
        md.append(f"| {n} | {m} | {100 * (a[:, c].mean() / base[:, c].mean() - 1):+.1f}% | {'<0.001' if p < 1e-3 else f'{p:.3f}'} |")
def tex_table(rows):
    out = ["\\begin{tabular}{lcccc}", "\\toprule", "Protocol & FND & HND & LND & Hops/round \\\\", "\\midrule"]
    for n in NAMES:
        x = np.array(rows[n], float)
        cell = lambda c: (f"{x[:, c].mean():.0f} $\\pm$ {ci95(x[:, c]):.0f}" if ci95(x[:, c]) > 0 else f"{x[:, c].mean():.0f}")
        out.append(f"{n} & {cell(0)} & {cell(1)} & {cell(2)} & {x[:, 3].mean():.1f} \\\\")
    return "\n".join(out + ["\\bottomrule", "\\end{tabular}"]) + "\n"

open(os.path.join(HERE, "bench_random_table.tex"), "w").write(tex_table(rows))
if os.path.exists(real):
    open(os.path.join(HERE, "bench_real_table.tex"), "w").write(tex_table(rows_real))
wt = ["\\begin{tabular}{llcc}", "\\toprule", "Protocol & Metric & Change vs PEGASIS & $p$ \\\\", "\\midrule"]
for n in ("PEGASIS-2opt", "PEGASIS-E", "PEGASIS-MC", "LEACH"):
    a_ = np.array(rows[n], float)
    for c, m in enumerate(("FND", "HND", "LND")):
        p = stats.wilcoxon(a_[:, c], base[:, c]).pvalue
        wt.append(f"{n} & {m} & {100 * (a_[:, c].mean() / base[:, c].mean() - 1):+.1f}\\% & {'$<$0.001' if p < 1e-3 else f'{p:.3f}'} \\\\")
open(os.path.join(HERE, "bench_wilcoxon_table.tex"), "w").write("\n".join(wt + ["\\bottomrule", "\\end{tabular}"]) + "\n")
text = "\n".join(md)
open(os.path.join(HERE, "benchmark_results.md"), "w").write(text)
print(text)
