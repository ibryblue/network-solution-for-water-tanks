"""
wsn_sim.py -- Energy-aware WSN routing simulator: LEACH vs PEGASIS (+ Direct baseline)
=======================================================================================
Author : Ibrahim Abuzant (An-Najah National University)
Supervisor : Prof. Jihad Hamamreh

What this file contains
-----------------------
1. Params          : every physical/protocol constant in ONE place (first-order radio model).
2. e_tx / e_rx     : radio energy equations (Heinzelman et al.).
3. make_layout     : node deployment (random or jittered street grid).
4. run_direct      : baseline, every node transmits straight to the sink.
5. run_leach       : LEACH (randomised cluster heads, threshold T(n)).
6. run_pegasis     : PEGASIS (greedy chain, rotating leader, data fusion along the chain).
7. selftest        : hand-computed checks that prove the simulator is correct.

Only NumPy is required.  Run `python wsn_sim.py` to execute the self-tests.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
import numpy as np


# --------------------------------------------------------------------------- #
# 1. PARAMETERS
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Params:
    # ---- deployment (neighbourhood scale) ----
    n_nodes: int = 100            # one node per building (rooftop water tank)
    field: float = 200.0          # side of the square neighbourhood block [m]
    sink: tuple = (100.0, 250.0)  # base station / community point [m]
    # ---- energy model (Heinzelman et al., 2000/2002) ----
    e0: float = 0.5               # initial energy per node [J]  (normalised, see report)
    e_elec: float = 50e-9         # electronics energy  [J/bit]
    eps_fs: float = 10e-12        # free-space amplifier [J/bit/m^2]
    eps_mp: float = 0.0013e-12    # multipath amplifier  [J/bit/m^4]
    e_da: float = 5e-9            # data-fusion energy   [J/bit/signal]
    # ---- packets ----
    k_data: int = 4000            # data packet [bits]
    k_ctrl: int = 200             # control packet (ADV / JOIN / SCHEDULE) [bits]
    # ---- LEACH ----
    p: float = 0.05               # desired fraction of cluster heads per round
    # ---- optional realism (defaults = off, so earlier results are unchanged) ----
    attempts: float = 1.0         # mean transmissions per packet (ARQ retries): 1.5 = 50 % extra tx AND rx energy
    e_sleep: float = 0.0          # idle / sleep energy per living node per round [J]
    # ---- simulation ----
    max_rounds: int = 30000

    @property
    def d0(self) -> float:
        """Crossover distance between free-space and multipath models [m]."""
        return float(np.sqrt(self.eps_fs / self.eps_mp))


# --------------------------------------------------------------------------- #
# 2. RADIO MODEL
# --------------------------------------------------------------------------- #
def e_tx(P: Params, k, d):
    """Energy to transmit k bits over distance d (vectorised over d)."""
    d = np.asarray(d, dtype=float)
    amp = np.where(d < P.d0, P.eps_fs * d**2, P.eps_mp * d**4)
    return (k * P.e_elec + k * amp) * P.attempts


def e_rx(P: Params, k):
    """Energy to receive k bits."""
    return k * P.e_elec * P.attempts


def e_fuse(P: Params, n_signals, k=None):
    """Energy to fuse n_signals packets of k bits into one (0 if nothing to fuse)."""
    k = P.k_data if k is None else k
    n_signals = np.asarray(n_signals)
    return np.where(n_signals >= 2, n_signals * k * P.e_da, 0.0)


# --------------------------------------------------------------------------- #
# 3. DEPLOYMENT
# --------------------------------------------------------------------------- #
def make_layout(P: Params, rng: np.random.Generator, kind: str = "random") -> np.ndarray:
    """Return an (N,2) array of node coordinates.
    kind='random' : uniform random in the block (standard in the LEACH literature)
    kind='grid'   : jittered street grid, a crude model of buildings along streets
    """
    N, L = P.n_nodes, P.field
    if kind == "random":
        return rng.uniform(0, L, size=(N, 2))
    if kind == "grid":
        side = int(np.ceil(np.sqrt(N)))
        step = L / side
        xs, ys = np.meshgrid((np.arange(side) + 0.5) * step, (np.arange(side) + 0.5) * step)
        pts = np.column_stack([xs.ravel(), ys.ravel()])
        pts = pts[rng.permutation(len(pts))[:N]]
        pts = pts + rng.normal(0, 0.15 * step, size=pts.shape)
        return np.clip(pts, 0, L)
    raise ValueError(kind)


def _dist_to_sink(P, pos):
    return np.hypot(pos[:, 0] - P.sink[0], pos[:, 1] - P.sink[1])


# --------------------------------------------------------------------------- #
# helpers shared by all protocols
# --------------------------------------------------------------------------- #
class _Tracker:
    """Records alive-count / residual energy per round and the key lifetime metrics."""

    def __init__(self, P, record=False):
        self.P = P
        self.record = record        # keep a full per-round log (used by the live dashboard)
        self.log = []
        self.role = None            # who did what this round (set by the protocol before end_round)
        self.alive_curve, self.energy_curve = [], []
        self.fnd = self.hnd = self.lnd = None
        self.death_round = np.full(P.n_nodes, np.nan)
        self.sink_packets = 0       # packets that reached the sink
        self.readings = 0           # sensor readings represented in those packets
        self.hops = []              # sequential transmissions needed per round (latency proxy)

    def end_round(self, r, E, alive):
        P = self.P
        if P.e_sleep:
            E[alive] -= P.e_sleep               # idle / sleep consumption of every living node
        died = alive & (E <= 0)
        E[died] = 0.0
        alive[died] = False
        self.death_round[died & np.isnan(self.death_round)] = r + 1
        n_alive = int(alive.sum())
        self.alive_curve.append(n_alive)
        self.energy_curve.append(float(E.sum()))
        if self.record:
            self.log.append(dict(E=E.astype(np.float32), alive=alive.copy(), role=self.role))
        self.role = None
        if self.fnd is None and n_alive < P.n_nodes:
            self.fnd = r + 1
        if self.hnd is None and n_alive <= P.n_nodes / 2:
            self.hnd = r + 1
        if self.lnd is None and n_alive == 0:
            self.lnd = r + 1
        return n_alive == 0

    def result(self, E, extra=None):
        out = dict(
            alive=np.array(self.alive_curve), energy=np.array(self.energy_curve),
            fnd=self.fnd, hnd=self.hnd, lnd=self.lnd,
            death_round=self.death_round, sink_packets=self.sink_packets,
            readings=self.readings, hops=float(np.mean(self.hops)) if self.hops else 0.0,
            E_final=E.copy(),
        )
        if self.record:
            out["log"] = self.log
        if extra:
            out.update(extra)
        return out


# --------------------------------------------------------------------------- #
# 4. DIRECT TRANSMISSION (baseline)
# --------------------------------------------------------------------------- #
def run_direct(P: Params, pos: np.ndarray, rng=None, snap_round=None, record=False):
    N = P.n_nodes
    E = np.full(N, P.e0)
    alive = np.ones(N, bool)
    ds = _dist_to_sink(P, pos)
    T = _Tracker(P, record)
    cost = e_tx(P, P.k_data, ds)
    for r in range(P.max_rounds):
        idx = np.flatnonzero(alive)
        E[idx] -= cost[idx]
        T.sink_packets += idx.size
        T.readings += idx.size
        T.hops.append(1)
        T.role = dict(kind="direct")
        if T.end_round(r, E, alive):
            break
    return T.result(E)


# --------------------------------------------------------------------------- #
# 5. LEACH
# --------------------------------------------------------------------------- #
def run_leach(P: Params, pos: np.ndarray, rng: np.random.Generator, snap_round: int | None = None, record=False):
    """LEACH with set-up phase (ADV, JOIN, SCHEDULE) and steady-state phase."""
    N = P.n_nodes
    E = np.full(N, P.e0)
    alive = np.ones(N, bool)
    eligible = np.ones(N, bool)             # "has not been a CH in the current epoch"
    cycle = int(round(1 / P.p))             # epoch length = 1/p rounds
    ds = _dist_to_sink(P, pos)
    T = _Tracker(P, record)
    snap = None

    for r in range(P.max_rounds):
        if r % cycle == 0:
            eligible[:] = alive             # new epoch: every living node is eligible again
        idx = np.flatnonzero(alive)
        # threshold T(n) = p / (1 - p * (r mod 1/p))
        thr = P.p / (1 - P.p * (r % cycle))
        is_ch = eligible & alive & (rng.random(N) < thr)
        heads = np.flatnonzero(is_ch)
        eligible[heads] = False

        if heads.size == 0:
            # rare: nobody volunteered -> fall back to direct transmission this round
            E[idx] -= e_tx(P, P.k_data, ds[idx])
            T.sink_packets += idx.size
            T.readings += idx.size
            T.hops.append(1)
            T.role = dict(kind="direct")
        else:
            members = idx[~is_ch[idx]]
            # ---- set-up phase ----
            # (a) every CH broadcasts an ADV strong enough to reach the farthest living node
            for h in heads:
                dfar = np.max(np.hypot(pos[idx, 0] - pos[h, 0], pos[idx, 1] - pos[h, 1]))
                E[h] -= e_tx(P, P.k_ctrl, dfar)
            # (b) every member hears all ADVs, joins the nearest CH
            E[members] -= e_rx(P, P.k_ctrl) * heads.size
            if members.size:
                dm = np.hypot(pos[members, None, 0] - pos[None, heads, 0],
                              pos[members, None, 1] - pos[None, heads, 1])
                nearest = dm.argmin(axis=1)
                dmin = dm[np.arange(members.size), nearest]
                E[members] -= e_tx(P, P.k_ctrl, dmin)                 # JOIN message
                n_mem = np.bincount(nearest, minlength=heads.size)    # members per CH
                E[heads] -= e_rx(P, P.k_ctrl) * n_mem                 # CH hears JOINs
                # (c) CH broadcasts TDMA schedule to its members
                dmax = np.zeros(heads.size)
                np.maximum.at(dmax, nearest, dmin)
                has = n_mem > 0
                E[heads[has]] -= e_tx(P, P.k_ctrl, dmax[has])
                E[members] -= e_rx(P, P.k_ctrl)
                # ---- steady-state phase ----
                E[members] -= e_tx(P, P.k_data, dmin)                 # member -> CH
                E[heads] -= e_rx(P, P.k_data) * n_mem                 # CH receives
                E[heads] -= e_fuse(P, n_mem + 1)                      # CH fuses own + members
            else:
                nearest = np.array([], int)
            E[heads] -= e_tx(P, P.k_data, ds[heads])                  # CH -> sink
            T.sink_packets += heads.size
            T.readings += idx.size
            T.hops.append(2 if members.size else 1)
            T.role = dict(kind="leach", heads=heads.copy(), members=members.copy(),
                          assign=heads[nearest].copy() if members.size else np.array([], int))
            if snap_round is not None and r == snap_round:
                snap = dict(heads=heads.copy(), members=members.copy(),
                            assign=heads[nearest].copy() if members.size else np.array([], int))
        if T.end_round(r, E, alive):
            break
    return T.result(E, dict(snapshot=snap))


# --------------------------------------------------------------------------- #
# 6. PEGASIS
# --------------------------------------------------------------------------- #
def build_chain(pos: np.ndarray, idx: np.ndarray, ds: np.ndarray) -> np.ndarray:
    """Greedy chain: start at the node farthest from the sink, then repeatedly
    append the closest node that is not yet on the chain."""
    remaining = list(idx)
    start = max(remaining, key=lambda i: ds[i])
    chain = [start]
    remaining.remove(start)
    rem = np.array(remaining, dtype=int)
    while rem.size:
        last = chain[-1]
        d = np.hypot(pos[rem, 0] - pos[last, 0], pos[rem, 1] - pos[last, 1])
        j = int(d.argmin())
        chain.append(int(rem[j]))
        rem = np.delete(rem, j)
    return np.array(chain, dtype=int)


def _gather_cost(P, seg, L, n, d_bs):
    """Energy spent by each of the n nodes of ONE chain in one round (leader at chain position L).
    seg[i] = length of the link between chain positions i and i+1;  d_bs = leader-to-base-station distance."""
    k = P.k_data
    cost = np.zeros(n)
    if L > 0:                                           # left side passes data towards the leader
        cost[0:L] += e_tx(P, k, seg[0:L])
        cost[1:L + 1] += e_rx(P, k)
        if L > 1:
            cost[1:L] += e_fuse(P, 2)
    if L < n - 1:                                       # right side passes data towards the leader
        cost[L + 1:n] += e_tx(P, k, seg[L:n - 1])
        cost[L:n - 1] += e_rx(P, k)
        if L < n - 2:
            cost[L + 1:n - 1] += e_fuse(P, 2)
    incoming = int(L > 0) + int(L < n - 1)              # leader fuses everything, sends ONE packet to the BS
    cost[L] += e_fuse(P, incoming + 1)
    cost[L] += e_tx(P, k, d_bs)
    return cost


def _greedy_chain(P, pos, idx, ds):
    return build_chain(pos, idx, ds)


def build_chain_2opt(P, pos, idx, ds, max_passes=30):
    """Chain = open Hamiltonian path.  Start from the greedy chain, then apply the classic 2-opt
    local search (reverse a segment whenever that lowers the total link ENERGY) until no move helps."""
    chain = build_chain(pos, idx, ds)
    n = len(chain)
    if n < 4:
        return chain
    x, y = pos[chain, 0], pos[chain, 1]
    C = e_tx(P, P.k_data, np.hypot(x[:, None] - x[None, :], y[:, None] - y[None, :]))   # link-energy matrix
    order = np.arange(n)
    for _ in range(max_passes):
        improved = False
        for i in range(n - 1):
            a, b = (order[i - 1] if i > 0 else -1), order[i]
            js = np.arange(i + 1, n)
            c = order[js]
            dn = np.where(js < n - 1, order[np.minimum(js + 1, n - 1)], -1)
            old = (C[a, b] if a >= 0 else 0.0) + np.where(dn >= 0, C[c, dn], 0.0)
            new = (C[a, c] if a >= 0 else 0.0) + np.where(dn >= 0, C[b, dn], 0.0)
            gain = old - new
            k = int(gain.argmax())
            if gain[k] > 1e-15:
                j = int(js[k])
                order[i:j + 1] = order[i:j + 1][::-1].copy()
                improved = True
        if not improved:
            break
    return chain[order]


def run_pegasis(P: Params, pos: np.ndarray, rng=None, snap_round: int | None = None, record=False,
                chain_fn=_greedy_chain):
    N = P.n_nodes
    E = np.full(N, P.e0)
    alive = np.ones(N, bool)
    ds = _dist_to_sink(P, pos)
    T = _Tracker(P, record)
    chain, last_alive_key, snap = None, None, None
    k = P.k_data

    for r in range(P.max_rounds):
        idx = np.flatnonzero(alive)
        n = idx.size
        key = idx.tobytes()
        if key != last_alive_key:                       # rebuild chain only when a node died
            chain = chain_fn(P, pos, idx, ds)
            seg = np.hypot(np.diff(pos[chain, 0]), np.diff(pos[chain, 1]))   # link lengths
            last_alive_key = key
        leader_node = idx[r % n]                        # rotating leader: i mod N
        L = int(np.flatnonzero(chain == leader_node)[0])
        cost = _gather_cost(P, seg, L, n, ds[chain[L]])

        E[chain] -= cost
        T.sink_packets += 1
        T.readings += n
        T.hops.append(max(L, n - 1 - L) + 1)            # sequential transmissions (latency proxy)
        T.role = dict(kind="pegasis", chain=chain, leader=int(leader_node))
        if snap_round is not None and r == snap_round:
            snap = dict(chain=chain.copy(), leader=int(leader_node))
        if T.end_round(r, E, alive):
            break
    return T.result(E, dict(snapshot=snap))


def run_pegasis_2opt(P, pos, rng=None, snap_round=None, record=False):
    """PEGASIS whose chain is improved with 2-opt local search (a TSP heuristic) instead of the greedy chain."""
    return run_pegasis(P, pos, rng, snap_round, record, chain_fn=build_chain_2opt)


def run_pegasis_variant(P, pos, rng=None, snap_round=None, record=False,
                        chain="2opt", cut=True, leader="energy", threshold=None):
    """One runner for the whole PEGASIS family; every option is an independent switch (used for the ablation).
       chain  : "greedy" (original PEGASIS) | "2opt" (greedy + 2-opt local search)
       cut    : False = one chain | True = cut the chain at every link >= threshold (default d0)
       leader : "rotate" = round-robin inside each chain (original PEGASIS rule)
                "energy" = node with the largest residual_energy / E_tx(to BS)
       (chain="greedy", cut=False, leader="rotate") is exactly the original PEGASIS."""
    N = P.n_nodes
    thr = P.d0 if threshold is None else threshold
    builder = build_chain_2opt if chain == "2opt" else _greedy_chain
    E = np.full(N, P.e0)
    alive = np.ones(N, bool)
    ds = _dist_to_sink(P, pos)
    T = _Tracker(P, record)
    last_key, segments = None, []
    for r in range(P.max_rounds):
        idx = np.flatnonzero(alive)
        key = idx.tobytes()
        if key != last_key:
            ch = builder(P, pos, idx, ds)
            links = np.hypot(np.diff(pos[ch, 0]), np.diff(pos[ch, 1]))
            parts = np.split(ch, np.flatnonzero(links >= thr) + 1) if cut else [ch]
            segments = [(p, np.hypot(np.diff(pos[p, 0]), np.diff(pos[p, 1]))) for p in parts]
            last_key = key
        leaders, chains, hops = [], [], 0
        for members, seg in segments:
            n_s = len(members)
            if leader == "energy":
                L = int((E[members] / e_tx(P, P.k_data, ds[members])).argmax())
            else:
                L = int(np.flatnonzero(members == np.sort(members)[r % n_s])[0])
            E[members] -= _gather_cost(P, seg, L, n_s, ds[members[L]])
            leaders.append(int(members[L])); chains.append(members)
            hops = max(hops, max(L, n_s - 1 - L) + 1)
        T.sink_packets += len(segments)
        T.readings += idx.size
        T.hops.append(hops)
        T.role = dict(kind="pegasis_mc", chains=chains, leaders=leaders)
        if T.end_round(r, E, alive):
            break
    return T.result(E)


def run_pegasis_mc(P, pos, rng=None, snap_round=None, record=False, threshold=None):
    """PEGASIS-MC (multi-chain): 2-opt chain, cut at links >= d0, energy-aware leader in every chain."""
    return run_pegasis_variant(P, pos, rng, snap_round, record, chain="2opt", cut=True, leader="energy",
                               threshold=threshold)


def run_pegasis_e(P, pos, rng=None, snap_round=None, record=False):
    """PEGASIS-E: 2-opt chain + energy-aware leader, ONE chain (the best variant found by the ablation study)."""
    return run_pegasis_variant(P, pos, rng, snap_round, record, chain="2opt", cut=False, leader="energy")


PROTOCOLS = {"Direct": run_direct, "LEACH": run_leach, "PEGASIS": run_pegasis, "PEGASIS-2opt": run_pegasis_2opt,
             "PEGASIS-E": run_pegasis_e, "PEGASIS-MC": run_pegasis_mc}


# --------------------------------------------------------------------------- #
# 7. SELF-TESTS  (hand-computed numbers; if these pass, the simulator is trustworthy)
# --------------------------------------------------------------------------- #
def selftest(verbose=True):
    P = Params()
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        if verbose:
            print(f"[{'PASS' if cond else 'FAIL'}] {name}")

    # T1: radio model is continuous at the crossover distance d0
    d0 = P.d0
    fs = P.k_data * P.eps_fs * d0**2
    mp = P.k_data * P.eps_mp * d0**4
    check("T1 free-space and multipath curves meet at d0 (%.2f m)" % d0, np.isclose(fs, mp))

    # T2: Direct transmission -> death round of every node equals ceil(E0/cost) analytically
    rng = np.random.default_rng(1)
    P2 = replace(P, n_nodes=20)
    pos = make_layout(P2, rng)
    res = run_direct(P2, pos)
    expected = np.ceil(P2.e0 / e_tx(P2, P2.k_data, _dist_to_sink(P2, pos)) - 1e-9)
    check("T2 Direct: simulated death rounds == analytic ceil(E0/E_tx)",
          np.all(np.abs(res["death_round"] - expected) <= 1) and res["fnd"] == res["death_round"].min())

    # T3: PEGASIS, 3 nodes on a line, ONE round, compare against independent hand formula
    P3 = replace(P, n_nodes=3, sink=(60.0, 100.0), max_rounds=1)
    pos3 = np.array([[0.0, 0.0], [30.0, 0.0], [60.0, 0.0]])
    res = run_pegasis(P3, pos3)
    k = P3.k_data
    tx = lambda d: k * P3.e_elec + k * P3.eps_fs * d**2           # free-space (d < d0)
    rx = k * P3.e_elec
    d_sink = np.hypot(60.0, 100.0)                                 # 116.6 m > d0 -> multipath model
    tx_sink = k * P3.e_elec + k * P3.eps_mp * d_sink**4
    exp = np.array([
        rx + 2 * k * P3.e_da + tx_sink,             # leader: rx from node1, fuse 2 signals, tx to sink
        rx + 2 * k * P3.e_da + tx(30.0),            # relay : rx from node2, fuse 2, tx to node0
        tx(30.0),                                   # end   : tx to node1
    ])
    check("T3 PEGASIS 3-node round matches hand calculation",
          np.allclose(P3.e0 - res["E_final"], exp, rtol=1e-9, atol=1e-15))

    # T4: energy never increases and alive count never increases (LEACH & PEGASIS)
    rng = np.random.default_rng(7)
    pos = make_layout(P, rng)
    for name, fn in (("LEACH", run_leach), ("PEGASIS", run_pegasis)):
        res = fn(P, pos, np.random.default_rng(3))
        mono = np.all(np.diff(res["energy"]) <= 1e-12) and np.all(np.diff(res["alive"]) <= 0)
        check(f"T4 {name}: residual energy and alive count are monotonically non-increasing", mono)

    # T5: ordering sanity -> farthest-from-sink node dies first under Direct
    res = run_direct(P, pos)
    check("T5 Direct: farthest node from the sink dies first",
          int(np.nanargmin(res["death_round"])) == int(np.argmax(_dist_to_sink(P, pos))))
    # T6: 2-opt chain is a permutation of the nodes and never costs more link-energy than the greedy chain
    rng = np.random.default_rng(11)
    pos6 = make_layout(P, rng)
    idx6 = np.arange(P.n_nodes)
    ds6 = _dist_to_sink(P, pos6)
    g, o = build_chain(pos6, idx6, ds6), build_chain_2opt(P, pos6, idx6, ds6)
    cost = lambda ch: float(e_tx(P, P.k_data, np.hypot(np.diff(pos6[ch, 0]), np.diff(pos6[ch, 1]))).sum())
    check("T6 2-opt chain: same node set, total link energy <= greedy (%.4f <= %.4f J)" % (cost(o), cost(g)),
          sorted(o.tolist()) == idx6.tolist() and cost(o) <= cost(g) + 1e-12)

    # T7: PEGASIS-MC, 3 nodes, one link longer than d0 -> 2 chains; compare one round with the hand calculation
    P7 = replace(P, n_nodes=3, sink=(0.0, 100.0), max_rounds=1)
    pos7 = np.array([[0.0, 0.0], [30.0, 0.0], [300.0, 0.0]])
    res = run_pegasis_mc(P7, pos7)
    k = P7.k_data
    txfs = lambda d: k * P7.e_elec + k * P7.eps_fs * d**2
    txmp = lambda d: k * P7.e_elec + k * P7.eps_mp * d**4
    rx = k * P7.e_elec
    exp7 = np.array([
        rx + 2 * k * P7.e_da + txmp(100.0),         # node0: leader of chain [1,0] (100 m > d0 -> multipath), rx, fuse 2, tx BS
        txfs(30.0),                                  # node1: end of chain, tx to node0
        txmp(np.hypot(300.0, 100.0)),                # node2: alone in its own chain, tx straight to BS
    ])
    check("T7 PEGASIS-MC: 2 chains, one round matches hand calculation",
          np.allclose(P7.e0 - res["E_final"], exp7, rtol=1e-9, atol=1e-15))
    # T8: the generic runner reproduces the ORIGINAL protocols exactly (same lifetimes, same final energies)
    pos8 = make_layout(P, np.random.default_rng(5))
    a, b = run_pegasis(P, pos8), run_pegasis_variant(P, pos8, chain="greedy", cut=False, leader="rotate")
    c, d = run_pegasis_2opt(P, pos8), run_pegasis_variant(P, pos8, chain="2opt", cut=False, leader="rotate")
    check("T8 generic runner == original PEGASIS and PEGASIS-2opt (identical lifetimes and energies)",
          (a["fnd"], a["hnd"], a["lnd"]) == (b["fnd"], b["hnd"], b["lnd"]) and np.allclose(a["energy"], b["energy"])
          and (c["fnd"], c["hnd"], c["lnd"]) == (d["fnd"], d["hnd"], d["lnd"]) and np.allclose(c["energy"], d["energy"]))

    # T9: realism switches -- retries cost energy, sleep costs energy, and defaults change nothing
    Pa, Ps = replace(P, attempts=2.0), replace(P, e_sleep=1e-3)
    base, dbl, slp = run_direct(P, pos8), run_direct(Pa, pos8), run_direct(Ps, pos8)
    check("T9 attempts=2 halves Direct lifetime (+-1 round) and sleep energy shortens it",
          abs(dbl["fnd"] * 2 - base["fnd"]) <= 2 and slp["fnd"] < base["fnd"] and replace(P).attempts == 1.0)
    return ok


if __name__ == "__main__":
    print("All self-tests passed." if selftest() else "SOME TESTS FAILED.")
