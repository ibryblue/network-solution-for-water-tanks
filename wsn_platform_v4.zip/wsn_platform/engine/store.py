"""
store.py -- SQLite experiment store (standard library only).
Every simulated run that the API computes is saved, so results survive restarts and can be listed / compared later.

  runs(id, key UNIQUE, created, protocol, layout, seed, n, rounds, fnd, hnd, lnd, avg_hops, sink_packets, readings)
  curves(run_id -> runs.id ON DELETE CASCADE, alive JSON, energy JSON)

All SQL uses ? placeholders (parameterised queries), so user input can never change the SQL statement.
"""
import json, os, sqlite3, time
from contextlib import closing

HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("WSN_DB", os.path.join(HERE, "wsn.db"))
SCHEMA = """
CREATE TABLE IF NOT EXISTS runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT UNIQUE NOT NULL, created TEXT NOT NULL,
  protocol TEXT NOT NULL, layout TEXT NOT NULL, seed INTEGER NOT NULL, n INTEGER NOT NULL, rounds INTEGER,
  fnd INTEGER, hnd INTEGER, lnd INTEGER, avg_hops REAL, sink_packets INTEGER, readings INTEGER);
CREATE TABLE IF NOT EXISTS curves(
  run_id INTEGER PRIMARY KEY REFERENCES runs(id) ON DELETE CASCADE, alive TEXT NOT NULL, energy TEXT NOT NULL);
"""


def connect():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    c.executescript(SCHEMA)
    return c


def save_run(s: dict, layout: str) -> int:
    """Insert (or replace) one run summary produced by platform_core.summary()."""
    key = f"{s['protocol']}|{layout}|{s['seed']}|{s['n']}"
    with closing(connect()) as c, c:
        c.execute("DELETE FROM runs WHERE key = ?", (key,))          # replacing also deletes the old curve (CASCADE)
        cur = c.execute(
            "INSERT INTO runs(key, created, protocol, layout, seed, n, rounds, fnd, hnd, lnd, avg_hops, sink_packets, readings)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (key, time.strftime("%Y-%m-%d %H:%M:%S"), s["protocol"], layout, s["seed"], s["n"], s["rounds"],
             s["fnd"], s["hnd"], s["lnd"], s["avg_hops"], s["sink_packets"], s["readings"]))
        c.execute("INSERT INTO curves(run_id, alive, energy) VALUES (?,?,?)",
                  (cur.lastrowid, json.dumps(s["alive_curve"]), json.dumps(s["energy_curve"])))
        return cur.lastrowid


def history(limit: int = 20, protocol: str | None = None) -> list:
    sql = "SELECT id, created, protocol, layout, seed, n, rounds, fnd, hnd, lnd, avg_hops FROM runs"
    args: tuple = ()
    if protocol:
        sql += " WHERE protocol = ?"
        args = (protocol,)
    sql += " ORDER BY id DESC LIMIT ?"
    with closing(connect()) as c:
        return [dict(r) for r in c.execute(sql, args + (int(limit),))]


def curve(run_id: int):
    with closing(connect()) as c:
        r = c.execute("SELECT r.protocol, r.layout, r.seed, r.n, c.alive, c.energy FROM runs r JOIN curves c ON c.run_id = r.id"
                      " WHERE r.id = ?", (int(run_id),)).fetchone()
    if r is None:
        return None
    return dict(id=int(run_id), protocol=r["protocol"], layout=r["layout"], seed=r["seed"], n=r["n"],
                alive=json.loads(r["alive"]), energy=json.loads(r["energy"]))


def count() -> int:
    with closing(connect()) as c:
        return c.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
