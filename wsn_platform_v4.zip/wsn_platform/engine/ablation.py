"""
ablation.py -- WHY does PEGASIS-MC work?  An ablation study + a realism sensitivity study, run in PARALLEL.

PEGASIS-MC changes three things at once.  Here every combination of the three switches is run:
    chain  : greedy | 2opt          (how the chain is built)
    cut    : no | yes               (cut the chain at links >= d0 = 87.7 m)
    leader : rotate | energy        (round-robin leader  vs  residual-energy / cost-to-BS leader)
-> 8 variants.  (greedy, no, rotate) is the original PEGASIS.

Usage:   python ablation.py                 (30 random layouts + the real layout; uses all CPU cores)
         python ablation.py --workers 1     (sequential; gives identical numbers)
         python ablation.py --seeds 5       (quick test)
Needs numpy + scipy.  Writes ablation_results.md, ablation_table.tex, ablation_effects.tex,
realism_results.md, realism_table.tex next to this file.
"""
import argparse, itertools, json, os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import replace
import numpy as np
from scipy import stats
from wsn_sim import Params, PROTOCOLS, make_layout, run_pegasis_variant

HERE = os.path.dirname(os.path.abspath(__file__))
REAL = os.path.join(HERE, "real_layout.json")
CHAINS, CUTS, LEADERS = ("greedy", "2opt"), (False, True), ("rotate", "energy")
VARIANTS = list(itertools.product(CHAINS, CUTS, LEADERS))
PR = replace(Params(), n_nodes=80, field=400.0, sink=(200.0, 450.0))          # random layouts: same size as the real block


def vname(v):
    return f"{v[0]}/{'cut' if v[1] else 'nocut'}/{v[2]}"


def setup(layout, seed):
    if layout == "real":
        L = json.load(open(REAL))
        pos = np.array(L["positions"])
        return replace(Params(), n_nodes=len(pos), field=float(L["field"]), sink=tuple(L["sink"])), pos
    return PR, make_layout(PR, np.random.default_rng(seed))


def job(args):                      # runs in a worker process; arguments and result are plain picklable data
    v, layout, seed = args
    P, pos = setup(layout, seed)
    r = run_pegasis_variant(P, pos, None, None, False, chain=v[0], cut=v[1], leader=v[2])
    return v, seed, r["fnd"], r["hnd"], r["lnd"], r["hops"]


def run_jobs(jobs, workers):
    if workers <= 1:
        return [job(j) for j in jobs]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(job, jobs, chunksize=4))


def collect(rows, seeds):
    out = {v: np.zeros((len(seeds), 4)) for v in VARIANTS}
    pos = {s: i for i, s in enumerate(seeds)}
    for v, s, f, h, l, hp in rows:
        out[v][pos[s]] = (f, h, l, hp)
    return out


def ci95(x):
    return 0.0 if len(x) < 2 else float(stats.t.ppf(0.975, len(x) - 1) * np.std(x, ddof=1) / np.sqrt(len(x)))


def effects(res):
    """Main effect of each switch: change of the metric when only that switch is turned on, averaged over the others."""
    rows = []
    for fi, (fname, off, on) in enumerate((("2-opt chain (vs greedy)", "greedy", "2opt"), ("cut long links (vs no cut)", False, True),
                                           ("energy-aware leader (vs rotate)", "rotate", "energy"))):
        for c, m in enumerate(("FND", "HND", "LND")):
            a = np.mean([res[v][:, c] for v in VARIANTS if v[fi] == off], axis=0)
            b = np.mean([res[v][:, c] for v in VARIANTS if v[fi] == on], axis=0)
            p = stats.wilcoxon(a, b).pvalue if np.any(a != b) and len(a) > 5 else float("nan")
            rows.append((fname, m, 100 * (b.mean() / a.mean() - 1), p))
    return rows


def fmt_p(p):
    return "n/a" if p != p else ("<0.001" if p < 1e-3 else f"{p:.3f}")


def realism(workers_unused=None):
    """Real layout: how do ARQ retries and idle/sleep energy change the ranking?"""
    L = json.load(open(REAL))
    pos = np.array(L["positions"])
    base = replace(Params(), n_nodes=len(pos), field=float(L["field"]), sink=tuple(L["sink"]))
    rows = []
    for att, slp in itertools.product((1.0, 1.5, 2.0), (0.0, 1e-4, 5e-4)):
        P = replace(base, attempts=att, e_sleep=slp)
        for name in ("LEACH", "PEGASIS", "PEGASIS-2opt", "PEGASIS-E", "PEGASIS-MC"):
            seeds = range(10) if name == "LEACH" else [0]
            m = np.mean([[PROTOCOLS[name](P, pos, np.random.default_rng(10_000 + s))[k] for k in ("fnd", "hnd", "lnd")]
                         for s in seeds], axis=0)
            rows.append((att, slp, name, *m))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workers", type=int, default=os.cpu_count() or 1)
    ap.add_argument("--seeds", type=int, default=30)
    a = ap.parse_args()
    seeds = list(range(a.seeds))
    md = ["# Ablation study (PEGASIS family)", "", f"Workers: {a.workers}. FND/HND/LND = round of first / half / last node death.", ""]

    res = collect(run_jobs([(v, "random", s) for v in VARIANTS for s in seeds], a.workers), seeds)
    tex = ["\\begin{tabular}{lcccc}", "\\toprule", "Variant (chain/cut/leader) & FND & HND & LND & Hops/round \\\\", "\\midrule"]
    md += [f"## A. {a.seeds} random layouts (80 nodes, 400 m block), mean +- 95% CI", "",
           "| Variant (chain/cut/leader) | FND | HND | LND | hops/round |", "|---|---|---|---|---|"]
    for v in VARIANTS:
        x = res[v]
        cells = [f"{x[:, c].mean():.0f} \u00b1 {ci95(x[:, c]):.0f}" for c in range(3)] + [f"{x[:, 3].mean():.1f}"]
        md.append(f"| {vname(v)}{'  (= original PEGASIS)' if v == ('greedy', False, 'rotate') else ''} | " + " | ".join(cells) + " |")
        tex.append(vname(v) + " & " + " & ".join(c.replace("\u00b1", "$\\pm$") for c in cells) + " \\\\")
    tex += ["\\bottomrule", "\\end{tabular}"]
    open(os.path.join(HERE, "ablation_table.tex"), "w").write("\n".join(tex) + "\n")

    eff = effects(res)
    md += ["", "### Main effect of each switch (average change over the other two switches; paired Wilcoxon over layouts)", "",
           "| Switch turned on | Metric | Change | p |", "|---|---|---|---|"]
    etex = ["\\begin{tabular}{llcc}", "\\toprule", "Switch turned on & Metric & Change & $p$ (Wilcoxon) \\\\", "\\midrule"]
    for f, m, ch, p in eff:
        md.append(f"| {f} | {m} | {ch:+.1f}% | {fmt_p(p)} |")
        etex.append(f"{f} & {m} & {ch:+.1f}\\% & {fmt_p(p).replace('<', '$<$')} \\\\")
    etex += ["\\bottomrule", "\\end{tabular}"]
    open(os.path.join(HERE, "ablation_effects.tex"), "w").write("\n".join(etex) + "\n")

    if os.path.exists(REAL):
        rr = collect(run_jobs([(v, "real", 0) for v in VARIANTS], 1), [0])
        md += ["", "## B. REAL layout (80 OpenStreetMap buildings) - deterministic, one run each", "",
               "| Variant | FND | HND | LND | hops/round |", "|---|---|---|---|---|"]
        for v in VARIANTS:
            x = rr[v][0]
            md.append(f"| {vname(v)} | {x[0]:.0f} | {x[1]:.0f} | {x[2]:.0f} | {x[3]:.1f} |")
        rl = realism()
        md += ["", "# Realism sensitivity on the REAL layout", "",
               "attempts = mean transmissions per packet (ARQ retries); sleep = idle energy per node per round (J; E0 = 0.5 J).",
               "LEACH: mean of 10 runs; others deterministic.", "",
               "| attempts | sleep (J/round) | Protocol | FND | HND | LND |", "|---|---|---|---|---|---|"]
        rt = ["\\begin{tabular}{ccl rrr}", "\\toprule", "Attempts & Sleep (J/round) & Protocol & FND & HND & LND \\\\", "\\midrule"]
        for att, slp, name, f, h, l in rl:
            md.append(f"| {att} | {slp:g} | {name} | {f:.0f} | {h:.0f} | {l:.0f} |")
            rt.append(f"{att} & {slp:g} & {name} & {f:.0f} & {h:.0f} & {l:.0f} \\\\")
        rt += ["\\bottomrule", "\\end{tabular}"]
        open(os.path.join(HERE, "realism_table.tex"), "w").write("\n".join(rt) + "\n")
    open(os.path.join(HERE, "ablation_results.md"), "w").write("\n".join(md))
    print("\n".join(md))


if __name__ == "__main__":
    main()
