# Ablation study (PEGASIS family)

Workers: 1. FND/HND/LND = round of first / half / last node death.

## A. 30 random layouts (80 nodes, 400 m block), mean +- 95% CI

| Variant (chain/cut/leader) | FND | HND | LND | hops/round |
|---|---|---|---|---|
| greedy/nocut/rotate  (= original PEGASIS) | 38 ± 13 | 351 ± 27 | 936 ± 46 | 26.5 |
| greedy/nocut/energy | 42 ± 19 | 880 ± 26 | 961 ± 19 | 45.7 |
| greedy/cut/rotate | 12 ± 5 | 239 ± 31 | 1043 ± 46 | 14.7 |
| greedy/cut/energy | 17 ± 7 | 505 ± 98 | 956 ± 31 | 23.8 |
| 2opt/nocut/rotate | 112 ± 9 | 505 ± 22 | 1027 ± 37 | 31.3 |
| 2opt/nocut/energy | 569 ± 43 | 959 ± 15 | 985 ± 16 | 58.9 |
| 2opt/cut/rotate | 50 ± 15 | 413 ± 33 | 1071 ± 47 | 23.5 |
| 2opt/cut/energy | 278 ± 107 | 791 ± 60 | 953 ± 26 | 42.2 |

### Main effect of each switch (average change over the other two switches; paired Wilcoxon over layouts)

| Switch turned on | Metric | Change | p |
|---|---|---|---|
| 2-opt chain (vs greedy) | FND | +828.7% | <0.001 |
| 2-opt chain (vs greedy) | HND | +35.1% | <0.001 |
| 2-opt chain (vs greedy) | LND | +3.6% | <0.001 |
| cut long links (vs no cut) | FND | -53.0% | <0.001 |
| cut long links (vs no cut) | HND | -27.7% | <0.001 |
| cut long links (vs no cut) | LND | +2.9% | 0.052 |
| energy-aware leader (vs rotate) | FND | +325.5% | <0.001 |
| energy-aware leader (vs rotate) | HND | +108.2% | <0.001 |
| energy-aware leader (vs rotate) | LND | -5.5% | <0.001 |

## B. REAL layout (80 OpenStreetMap buildings) - deterministic, one run each

| Variant | FND | HND | LND | hops/round |
|---|---|---|---|---|
| greedy/nocut/rotate | 4 | 339 | 799 | 27.6 |
| greedy/nocut/energy | 4 | 893 | 933 | 44.2 |
| greedy/cut/rotate | 3 | 253 | 983 | 16.3 |
| greedy/cut/energy | 3 | 650 | 889 | 24.2 |
| 2opt/nocut/rotate | 160 | 493 | 975 | 32.8 |
| 2opt/nocut/energy | 677 | 925 | 945 | 57.0 |
| 2opt/cut/rotate | 160 | 511 | 979 | 32.2 |
| 2opt/cut/energy | 677 | 839 | 886 | 53.2 |

# Realism sensitivity on the REAL layout

attempts = mean transmissions per packet (ARQ retries); sleep = idle energy per node per round (J; E0 = 0.5 J).
LEACH: mean of 10 runs; others deterministic.

| attempts | sleep (J/round) | Protocol | FND | HND | LND |
|---|---|---|---|---|---|
| 1.0 | 0 | LEACH | 17 | 66 | 392 |
| 1.0 | 0 | PEGASIS | 4 | 339 | 799 |
| 1.0 | 0 | PEGASIS-2opt | 160 | 493 | 975 |
| 1.0 | 0 | PEGASIS-E | 677 | 925 | 945 |
| 1.0 | 0 | PEGASIS-MC | 677 | 839 | 886 |
| 1.0 | 0.0001 | LEACH | 17 | 66 | 339 |
| 1.0 | 0.0001 | PEGASIS | 4 | 308 | 706 |
| 1.0 | 0.0001 | PEGASIS-2opt | 157 | 448 | 820 |
| 1.0 | 0.0001 | PEGASIS-E | 596 | 790 | 809 |
| 1.0 | 0.0001 | PEGASIS-MC | 596 | 719 | 758 |
| 1.0 | 0.0005 | LEACH | 17 | 64 | 232 |
| 1.0 | 0.0005 | PEGASIS | 4 | 257 | 473 |
| 1.0 | 0.0005 | PEGASIS-2opt | 120 | 356 | 501 |
| 1.0 | 0.0005 | PEGASIS-E | 404 | 492 | 506 |
| 1.0 | 0.0005 | PEGASIS-MC | 404 | 474 | 492 |
| 1.5 | 0 | LEACH | 11 | 45 | 261 |
| 1.5 | 0 | PEGASIS | 3 | 227 | 532 |
| 1.5 | 0 | PEGASIS-2opt | 99 | 326 | 665 |
| 1.5 | 0 | PEGASIS-E | 460 | 630 | 653 |
| 1.5 | 0 | PEGASIS-MC | 460 | 543 | 609 |
| 1.5 | 0.0001 | LEACH | 11 | 45 | 237 |
| 1.5 | 0.0001 | PEGASIS | 3 | 212 | 468 |
| 1.5 | 0.0001 | PEGASIS-2opt | 99 | 315 | 594 |
| 1.5 | 0.0001 | PEGASIS-E | 421 | 565 | 585 |
| 1.5 | 0.0001 | PEGASIS-MC | 421 | 537 | 550 |
| 1.5 | 0.0005 | LEACH | 10 | 44 | 180 |
| 1.5 | 0.0005 | PEGASIS | 3 | 184 | 399 |
| 1.5 | 0.0005 | PEGASIS-2opt | 80 | 265 | 407 |
| 1.5 | 0.0005 | PEGASIS-E | 315 | 395 | 411 |
| 1.5 | 0.0005 | PEGASIS-MC | 315 | 374 | 385 |
| 2.0 | 0 | LEACH | 8 | 34 | 203 |
| 2.0 | 0 | PEGASIS | 2 | 157 | 417 |
| 2.0 | 0 | PEGASIS-2opt | 80 | 252 | 500 |
| 2.0 | 0 | PEGASIS-E | 348 | 478 | 499 |
| 2.0 | 0 | PEGASIS-MC | 348 | 450 | 460 |
| 2.0 | 0.0001 | LEACH | 8 | 33 | 191 |
| 2.0 | 0.0001 | PEGASIS | 2 | 167 | 450 |
| 2.0 | 0.0001 | PEGASIS-2opt | 80 | 255 | 458 |
| 2.0 | 0.0001 | PEGASIS-E | 325 | 439 | 461 |
| 2.0 | 0.0001 | PEGASIS-MC | 325 | 402 | 427 |
| 2.0 | 0.0005 | LEACH | 7 | 33 | 149 |
| 2.0 | 0.0005 | PEGASIS | 2 | 162 | 315 |
| 2.0 | 0.0005 | PEGASIS-2opt | 77 | 209 | 342 |
| 2.0 | 0.0005 | PEGASIS-E | 258 | 331 | 346 |
| 2.0 | 0.0005 | PEGASIS-MC | 258 | 313 | 332 |