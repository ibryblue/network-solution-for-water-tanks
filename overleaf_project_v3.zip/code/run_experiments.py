"""
run_experiments.py -- reproduces EVERY number, table and figure in the report.

Usage:   python run_experiments.py            (about 1-2 minutes on a laptop)
Output:  ../results/*.tex  (LaTeX tables)   ../results/*.csv/json   ../figures/*.pdf|png

Nothing in the report is typed by hand: the LaTeX file \\input{}s the tables written here.
"""
from __future__ import annotations
import json, os, sys
from dataclasses import replace
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

from wsn_sim import (Params, PROTOCOLS, make_layout, run_leach, run_pegasis, selftest,
                     build_chain, _dist_to_sink)

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "..", "figures")
RES = os.path.join(HERE, "..", "results")
os.makedirs(FIG, exist_ok=True)
os.makedirs(RES, exist_ok=True)

N_SEEDS_MAIN = 50
N_SEEDS_SENS = 30
COL = {"Direct": "#7f7f7f", "LEACH": "#d95f02", "PEGASIS": "#1b6ca8"}
MARK = {"Direct": "s", "LEACH": "o", "PEGASIS": "^"}

plt.rcParams.update({
    "font.family": "serif", "font.size": 9, "axes.labelsize": 9, "axes.titlesize": 9,
    "legend.fontsize": 8, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 150, "savefig.bbox": "tight",
})


def savefig(fig, name):
    fig.savefig(os.path.join(FIG, name + ".pdf"))
    fig.savefig(os.path.join(FIG, name + ".png"), dpi=200)
    plt.close(fig)


# ------------------------------------------------------------------------- #
# core experiment routine
# ------------------------------------------------------------------------- #
def run_many(P: Params, seeds, layout="random", protocols=("Direct", "LEACH", "PEGASIS"), keep_curves=False):
    """Run each protocol on the SAME random deployment for every seed (paired design)."""
    out = {p: dict(fnd=[], hnd=[], lnd=[], hops=[], sink_packets=[], readings=[], alive=[], energy=[])
           for p in protocols}
    for s in seeds:
        pos = make_layout(P, np.random.default_rng(s), layout)
        for p in protocols:
            res = PROTOCOLS[p](P, pos, np.random.default_rng(10_000 + s))
            for key in ("fnd", "hnd", "lnd", "hops", "sink_packets", "readings"):
                out[p][key].append(res[key])
            if keep_curves:
                out[p]["alive"].append(res["alive"])
                out[p]["energy"].append(res["energy"])
    for p in protocols:
        for key in ("fnd", "hnd", "lnd", "hops", "sink_packets", "readings"):
            out[p][key] = np.array(out[p][key], dtype=float)
    return out


def ci95(x):
    x = np.asarray(x, float)
    if len(x) < 2:
        return 0.0
    return float(stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x)))


def ms(x, fmt="{:.0f}"):
    return (fmt + r" $\pm$ " + fmt).format(np.mean(x), ci95(x))


def pad_mean(curves, fill):
    L = max(len(c) for c in curves)
    M = np.full((len(curves), L), fill, float)
    for i, c in enumerate(curves):
        M[i, :len(c)] = c
        M[i, len(c):] = c[-1] if fill is None else fill
    return M


def write(name, text):
    with open(os.path.join(RES, name), "w") as f:
        f.write(text)


# ------------------------------------------------------------------------- #
def main():
    assert selftest(verbose=True), "self-tests failed -> stop"
    P = Params()
    summary = {"params": {k: (list(v) if isinstance(v, tuple) else v) for k, v in P.__dict__.items()},
               "d0": P.d0, "seeds_main": N_SEEDS_MAIN, "seeds_sens": N_SEEDS_SENS}

    # ================= E1: baseline ======================================= #
    print("E1 baseline ...")
    seeds = range(N_SEEDS_MAIN)
    base = run_many(P, seeds, keep_curves=True)

    # --- table 1: lifetime metrics
    rows = []
    for p in ("Direct", "LEACH", "PEGASIS"):
        d = base[p]
        rows.append(f"{p} & {ms(d['fnd'])} & {ms(d['hnd'])} & {ms(d['lnd'])} & "
                    f"{d['hops'].mean():.1f} & {np.mean(d['sink_packets'] / d['lnd']):.2f} & "
                    f"{ms(d['readings'] / 1e4, '{:.1f}')} \\\\")
    write("tab_baseline.tex",
          "\\begin{tabular}{lcccccc}\n\\toprule\n"
          "Protocol & FND & HND & LND & Hops/round & Sink pkts/round & Readings ($\\times10^4$) \\\\\n"
          "\\midrule\n" + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")

    # --- table 2: paired Wilcoxon tests LEACH vs PEGASIS
    wrows = []
    for key, lab in (("fnd", "FND"), ("hnd", "HND"), ("lnd", "LND")):
        a, b = base["LEACH"][key], base["PEGASIS"][key]
        w = stats.wilcoxon(a, b)
        better = "PEGASIS" if b.mean() > a.mean() else "LEACH"
        gain = (b.mean() - a.mean()) / a.mean() * 100
        wrows.append(f"{lab} & {a.mean():.0f} & {b.mean():.0f} & {gain:+.1f}\\% & "
                     f"{('$<10^{-3}$' if w.pvalue < 1e-3 else f'{w.pvalue:.3f}')} & {better} \\\\")
        summary[f"wilcoxon_{key}"] = dict(p=float(w.pvalue), leach=float(a.mean()), pegasis=float(b.mean()))
    write("tab_wilcoxon.tex",
          "\\begin{tabular}{lccccc}\n\\toprule\n"
          "Metric & LEACH mean & PEGASIS mean & PEGASIS vs LEACH & $p$ (Wilcoxon) & Longer-lived \\\\\n"
          "\\midrule\n" + "\n".join(wrows) + "\n\\bottomrule\n\\end{tabular}\n")

    # --- summary json
    summary["baseline"] = {p: {k: float(np.mean(v)) for k, v in base[p].items() if k not in ("alive", "energy")}
                           for p in base}
    summary["baseline_ci"] = {p: {k: ci95(v) for k, v in base[p].items() if k in ("fnd", "hnd", "lnd")}
                              for p in base}

    # --- csv of raw per-seed values (for the appendix / reproducibility)
    with open(os.path.join(RES, "baseline_raw.csv"), "w") as f:
        f.write("seed,protocol,fnd,hnd,lnd,hops,sink_packets,readings\n")
        for i, s in enumerate(seeds):
            for p in base:
                d = base[p]
                f.write(f"{s},{p},{d['fnd'][i]:.0f},{d['hnd'][i]:.0f},{d['lnd'][i]:.0f},"
                        f"{d['hops'][i]:.3f},{d['sink_packets'][i]:.0f},{d['readings'][i]:.0f}\n")

    # --- Fig: alive nodes & residual energy vs round
    fig, ax = plt.subplots(figsize=(3.4, 2.5))
    for p in ("Direct", "LEACH", "PEGASIS"):
        M = pad_mean(base[p]["alive"], 0)
        m, sd = M.mean(0), M.std(0)
        x = np.arange(1, len(m) + 1)
        ax.plot(x, m, color=COL[p], label=p, lw=1.4)
        ax.fill_between(x, np.maximum(m - sd, 0), np.minimum(m + sd, P.n_nodes), color=COL[p], alpha=0.15, lw=0)
    ax.set_xlabel("Round"); ax.set_ylabel("Alive nodes"); ax.legend(frameon=False)
    savefig(fig, "fig_alive")

    fig, ax = plt.subplots(figsize=(3.4, 2.5))
    for p in ("Direct", "LEACH", "PEGASIS"):
        M = pad_mean(base[p]["energy"], 0)
        m = M.mean(0)
        ax.plot(np.arange(1, len(m) + 1), m, color=COL[p], label=p, lw=1.4)
    ax.set_xlabel("Round"); ax.set_ylabel("Total residual energy (J)"); ax.legend(frameon=False)
    savefig(fig, "fig_energy")

    # --- Fig: lifetime bars
    fig, ax = plt.subplots(figsize=(3.4, 2.5))
    w = 0.26
    for j, p in enumerate(("Direct", "LEACH", "PEGASIS")):
        vals = [base[p][k].mean() for k in ("fnd", "hnd", "lnd")]
        errs = [ci95(base[p][k]) for k in ("fnd", "hnd", "lnd")]
        ax.bar(np.arange(3) + (j - 1) * w, vals, w, yerr=errs, capsize=2, color=COL[p], label=p)
    ax.set_xticks(range(3)); ax.set_xticklabels(["FND", "HND", "LND"])
    ax.set_ylabel("Rounds (mean, 95% CI)"); ax.legend(frameon=False)
    savefig(fig, "fig_lifetime")

    # --- Fig: death-round ECDF (how abruptly does each protocol lose nodes?)
    fig, ax = plt.subplots(figsize=(3.4, 2.5))
    for p in ("Direct", "LEACH", "PEGASIS"):
        M = pad_mean(base[p]["alive"], 0)
        dead_frac = 1 - M.mean(0) / P.n_nodes
        ax.plot(np.arange(1, len(dead_frac) + 1), dead_frac * 100, color=COL[p], label=p, lw=1.4)
    ax.set_xlabel("Round"); ax.set_ylabel("Dead nodes (%)"); ax.legend(frameon=False)
    savefig(fig, "fig_dead_pct")

    # --- Fig: snapshot of one LEACH round and one PEGASIS round on the same deployment
    pos = make_layout(P, np.random.default_rng(0))
    rl = run_leach(P, pos, np.random.default_rng(10_000), snap_round=50)
    rp = run_pegasis(P, pos, None, snap_round=50)
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 3.4), sharey=True)
    for ax, title in zip(axs, ("(a) LEACH, round 51", "(b) PEGASIS, round 51")):
        ax.add_patch(plt.Rectangle((0, 0), P.field, P.field, fill=False, ec="k", lw=0.8, ls="--"))
        ax.set_xlim(-10, P.field + 10); ax.set_ylim(-10, P.sink[1] + 20)
        ax.set_aspect("equal"); ax.set_title(title); ax.set_xlabel("x (m)")
        ax.plot(*P.sink, marker="*", ms=14, color="gold", mec="k", ls="none", zorder=5, label="Sink")
    axs[0].set_ylabel("y (m)")
    s = rl["snapshot"]
    cmap = plt.get_cmap("tab10")
    for ci, h in enumerate(s["heads"]):
        mem = s["members"][s["assign"] == h]
        for m in mem:
            axs[0].plot([pos[m, 0], pos[h, 0]], [pos[m, 1], pos[h, 1]], color=cmap(ci % 10), lw=0.5, alpha=0.6)
        axs[0].scatter(pos[mem, 0], pos[mem, 1], s=9, color=cmap(ci % 10))
        axs[0].plot([pos[h, 0], P.sink[0]], [pos[h, 1], P.sink[1]], color=cmap(ci % 10), lw=0.9, ls=":")
        axs[0].scatter(pos[h, 0], pos[h, 1], s=55, marker="s", color=cmap(ci % 10), ec="k", zorder=4)
    s = rp["snapshot"]; ch = s["chain"]
    axs[1].plot(pos[ch, 0], pos[ch, 1], color=COL["PEGASIS"], lw=0.7, marker="o", ms=2.5)
    ld = s["leader"]
    axs[1].plot([pos[ld, 0], P.sink[0]], [pos[ld, 1], P.sink[1]], color="crimson", lw=1.1, ls=":")
    axs[1].scatter(pos[ld, 0], pos[ld, 1], s=70, marker="s", color="crimson", ec="k", zorder=4, label="Leader")
    axs[0].legend(loc="upper left", frameon=False); axs[1].legend(loc="upper left", frameon=False)
    savefig(fig, "fig_snapshot")

    # ================= E2: sink position ================================== #
    print("E2 sink position ...")
    sink_y = [100, 200, 250, 300, 400]
    seeds_s = range(N_SEEDS_SENS)
    e2 = {y: run_many(replace(P, sink=(100.0, float(y))), seeds_s) for y in sink_y}
    fig, axs = plt.subplots(1, 3, figsize=(6.9, 2.4), sharex=True)
    for ax, key, lab in zip(axs, ("fnd", "hnd", "lnd"), ("FND", "HND", "LND")):
        for p in ("Direct", "LEACH", "PEGASIS"):
            ax.errorbar(sink_y, [e2[y][p][key].mean() for y in sink_y],
                        yerr=[ci95(e2[y][p][key]) for y in sink_y], color=COL[p], marker=MARK[p],
                        ms=3.5, lw=1.1, capsize=2, label=p)
        ax.set_xlabel("Sink y-position (m)"); ax.set_title(lab)
    axs[0].set_ylabel("Rounds"); axs[0].legend(frameon=False)
    savefig(fig, "fig_sink")
    rows = []
    for y in sink_y:
        for p in ("LEACH", "PEGASIS"):
            pass
        rows.append(f"{y} & {e2[y]['LEACH']['fnd'].mean():.0f} & {e2[y]['PEGASIS']['fnd'].mean():.0f} & "
                    f"{e2[y]['LEACH']['hnd'].mean():.0f} & {e2[y]['PEGASIS']['hnd'].mean():.0f} & "
                    f"{e2[y]['LEACH']['lnd'].mean():.0f} & {e2[y]['PEGASIS']['lnd'].mean():.0f} \\\\")
    write("tab_sink.tex",
          "\\begin{tabular}{lcccccc}\n\\toprule\n"
          " & \\multicolumn{2}{c}{FND} & \\multicolumn{2}{c}{HND} & \\multicolumn{2}{c}{LND} \\\\\n"
          "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\n"
          "Sink $y$ (m) & LEACH & PEGASIS & LEACH & PEGASIS & LEACH & PEGASIS \\\\\n\\midrule\n"
          + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")

    # ================= E3: network size =================================== #
    print("E3 network size ...")
    Ns = [25, 50, 100, 150, 200]
    e3 = {n: run_many(replace(P, n_nodes=n), seeds_s, protocols=("LEACH", "PEGASIS")) for n in Ns}
    fig, axs = plt.subplots(1, 3, figsize=(6.9, 2.4), sharex=True)
    for ax, key, lab in zip(axs, ("fnd", "hnd", "lnd"), ("FND", "HND", "LND")):
        for p in ("LEACH", "PEGASIS"):
            ax.errorbar(Ns, [e3[n][p][key].mean() for n in Ns], yerr=[ci95(e3[n][p][key]) for n in Ns],
                        color=COL[p], marker=MARK[p], ms=3.5, lw=1.1, capsize=2, label=p)
        ax.set_xlabel("Number of nodes $N$"); ax.set_title(lab)
    axs[0].set_ylabel("Rounds"); axs[0].legend(frameon=False)
    savefig(fig, "fig_nodes")
    rows = [f"{n} & {e3[n]['LEACH']['fnd'].mean():.0f} & {e3[n]['PEGASIS']['fnd'].mean():.0f} & "
            f"{e3[n]['LEACH']['hnd'].mean():.0f} & {e3[n]['PEGASIS']['hnd'].mean():.0f} & "
            f"{e3[n]['LEACH']['lnd'].mean():.0f} & {e3[n]['PEGASIS']['lnd'].mean():.0f} & "
            f"{e3[n]['PEGASIS']['hops'].mean():.1f} \\\\" for n in Ns]
    write("tab_nodes.tex",
          "\\begin{tabular}{lccccccc}\n\\toprule\n"
          " & \\multicolumn{2}{c}{FND} & \\multicolumn{2}{c}{HND} & \\multicolumn{2}{c}{LND} & PEGASIS \\\\\n"
          "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\n"
          "$N$ & LEACH & PEGASIS & LEACH & PEGASIS & LEACH & PEGASIS & hops/round \\\\\n\\midrule\n"
          + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")

    # ================= E4: LEACH p ======================================== #
    print("E4 LEACH p ...")
    ps = [0.02, 0.05, 0.10, 0.15, 0.20]
    e4 = {pp: run_many(replace(P, p=pp), seeds_s, protocols=("LEACH",)) for pp in ps}
    peg_ref = run_many(P, seeds_s, protocols=("PEGASIS",))["PEGASIS"]
    fig, axs = plt.subplots(1, 3, figsize=(6.9, 2.4), sharex=True)
    for ax, key, lab in zip(axs, ("fnd", "hnd", "lnd"), ("FND", "HND", "LND")):
        ax.errorbar(ps, [e4[pp]["LEACH"][key].mean() for pp in ps], yerr=[ci95(e4[pp]["LEACH"][key]) for pp in ps],
                    color=COL["LEACH"], marker="o", ms=3.5, lw=1.1, capsize=2, label="LEACH")
        ax.axhline(peg_ref[key].mean(), color=COL["PEGASIS"], ls="--", lw=1.1, label="PEGASIS (reference)")
        ax.set_xlabel("LEACH $p$"); ax.set_title(lab)
    axs[0].set_ylabel("Rounds"); axs[0].legend(frameon=False)
    savefig(fig, "fig_p")
    rows = [f"{pp:.2f} & {ms(e4[pp]['LEACH']['fnd'])} & {ms(e4[pp]['LEACH']['hnd'])} & {ms(e4[pp]['LEACH']['lnd'])} \\\\"
            for pp in ps]
    write("tab_p.tex",
          "\\begin{tabular}{lccc}\n\\toprule\n$p$ & FND & HND & LND \\\\\n\\midrule\n"
          + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")

    # ================= E5: layout ========================================= #
    print("E5 layout ...")
    e5 = {lay: run_many(P, seeds_s, layout=lay, protocols=("LEACH", "PEGASIS")) for lay in ("random", "grid")}
    rows = []
    for lay, nm in (("random", "Uniform random"), ("grid", "Jittered street grid")):
        for p in ("LEACH", "PEGASIS"):
            d = e5[lay][p]
            rows.append(f"{nm} & {p} & {ms(d['fnd'])} & {ms(d['hnd'])} & {ms(d['lnd'])} \\\\")
    write("tab_layout.tex",
          "\\begin{tabular}{llccc}\n\\toprule\nLayout & Protocol & FND & HND & LND \\\\\n\\midrule\n"
          + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n")

    # ================= E6: why is PEGASIS FND so variable? ================ #
    print("E6 chain-link analysis ...")
    maxlink, fnd_p, nlong = [], [], []
    for i, sd in enumerate(range(N_SEEDS_MAIN)):
        pos_i = make_layout(P, np.random.default_rng(sd))
        ds_i = _dist_to_sink(P, pos_i)
        ch = build_chain(pos_i, np.arange(P.n_nodes), ds_i)
        seg = np.hypot(np.diff(pos_i[ch, 0]), np.diff(pos_i[ch, 1]))
        maxlink.append(seg.max())
        nlong.append(int((seg >= P.d0).sum()))
        fnd_p.append(base["PEGASIS"]["fnd"][i])
    maxlink, fnd_p, nlong = np.array(maxlink), np.array(fnd_p), np.array(nlong)
    rho, pval = stats.spearmanr(maxlink, fnd_p)
    summary["e6"] = dict(spearman_rho=float(rho), p=float(pval), mean_max_link=float(maxlink.mean()),
                         frac_layouts_with_link_ge_d0=float((nlong > 0).mean()),
                         mean_links_ge_d0=float(nlong.mean()), max_link_max=float(maxlink.max()))
    fig, ax = plt.subplots(figsize=(3.4, 2.5))
    ax.scatter(maxlink, fnd_p, s=14, color=COL["PEGASIS"], ec="k", lw=0.3)
    ax.axvline(P.d0, color="crimson", ls="--", lw=1, label=r"$d_0$ = %.1f m" % P.d0)
    ax.set_xlabel("Longest chain link (m)"); ax.set_ylabel("PEGASIS FND (rounds)")
    ax.legend(frameon=False)
    savefig(fig, "fig_chain_link")

    # ---- store everything the report text quotes
    summary["sink_sensitivity"] = {str(y): {p: {k: float(e2[y][p][k].mean()) for k in ("fnd", "hnd", "lnd")}
                                            for p in e2[y]} for y in sink_y}
    summary["node_sensitivity"] = {str(n): {p: {k: float(e3[n][p][k].mean()) for k in ("fnd", "hnd", "lnd", "hops")}
                                            for p in e3[n]} for n in Ns}
    summary["p_sensitivity"] = {str(pp): {k: float(e4[pp]["LEACH"][k].mean()) for k in ("fnd", "hnd", "lnd")}
                                for pp in ps}
    summary["layout"] = {lay: {p: {k: float(e5[lay][p][k].mean()) for k in ("fnd", "hnd", "lnd")}
                               for p in e5[lay]} for lay in e5}
    with open(os.path.join(RES, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print("done.")


if __name__ == "__main__":
    main()
